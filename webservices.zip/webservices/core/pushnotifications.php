<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

	/**
	 * Author : Trilochan Umath
	 * Email  : trilochanumath@cdnsol.com
	 * Timestamp : 01-Sep-2014 01:22 PM
	 * Copyright : www.cdnsol.com
	 */
	final class pushnotifications {

		public $_parents = array();
		public $_data = array();
		
		/// -- Hold Static Connection Object --
		private static $ref;
		/// -- Hold Connection Object --
		
		public function __construct() {
			/// -- Create Database Connection instance --
		}
		
		/**
		 * final static env::getInst
		 * @access Public
		 * @return Object
		 */
		final public static function getInst(){
			if(!is_object(pushnotifications::$ref))
			{
				pushnotifications::$ref=new pushnotifications(config::getInst());
			}
			return pushnotifications::$ref;
		}
		
		/**
		 *  This function is for send push notifications on user iPhone device - Start. 
		**/
		public function sendIphonePushNotification($deviceId) {
		
			/**
			 * @file
			 * sample_push.php
			 *
			 * Push demo
			 *
			 * LICENSE
			 *
			 * This source file is subject to the new BSD license that is bundled
			 * with this package in the file LICENSE.txt.
			 * It is also available through the world-wide-web at this URL:
			 * http://code.google.com/p/apns-php/wiki/License
			 * If you did not receive a copy of the license and are unable to
			 * obtain it through the world-wide-web, please send an email
			 * to aldo.armiento@gmail.com so we can send you a copy immediately.
			 *
			 * @author (C) 2010 Aldo Armiento (aldo.armiento@gmail.com)
			 * @version $Id: sample_push.php 65 2010-12-13 18:38:39Z aldo.armiento $
			 */

			// Adjust to your timezone
			//date_default_timezone_set('Europe/Rome');

			// Report all PHP errors
			
			
			require_once 'pushNotifications/ApnsPHP/Autoload.php';
			
			// Instanciate a new ApnsPHP_Push object
			$push = new ApnsPHP_Push( ApnsPHP_Abstract::ENVIRONMENT_PRODUCTION, dirname(__DIR__).'/core/pushNotifications/apns-dev.pem' );
			
				
			// Set the Root Certificate Autority to verify the Apple remote peer
			//$push->setRootCertificationAuthority('entrust_root_certification_authority.pem');

			// Connect to the Apple Push Notification Service
			$push->connect();
		
			// 
			
			foreach ($deviceId as $key => $value)
			{
				
				$deviceId 		= $value['deviceId'];
				$invitationId 	= $value['badgeToDoStarCount'];
				$pushMessage 	= $value['pushMessage'];
				$pushReceiverId = $value['userId'];
				$msgCount=$value['msgCount'];
				
		
			/*	$customerName 	= $value['customerName'];
				$customerEmail	= $value['customerEmail'];
				$recipientName	= $value['recipientName']; */
				$recipientEmail = $value['recipientEmail'];
				
				//$pushType = $value['pushType'];
				//$pushActivityType = $value['pushActivityType'];
				$checkId = 1;
				
				$message = new ApnsPHP_Message($deviceId);
				// Set a custom identifier. To get back this identifier use the getCustomIdentifier() method
				// over a ApnsPHP_Message object retrieved with the getErrors() message.
				$message->setCustomIdentifier("Message-Badge-3");
				//$badgeCount = intval($deviceId);
				$badgeCount =1;
				$message->setBadge($msgCount);
				// Set a simple welcome text
				$message->setText($pushMessage);
				// Play the default sound
				$message->setSound();
				
				// Set a custom property
				$message->setCustomProperty('post_data', 
				array( 	"pushMessage" => $pushMessage,
						"deviceId" => $deviceId,
					
					//	'recipientEmail'=>$recipientEmail
					)); 
				
				//$message->setCustomProperty('post_data', array( "pushReceiverId" => $pushReceiverId, "invitationId" => $invitationId, "pushMessage" => $pushMessage,"deviceId" => $deviceId)); 
				
				// Set another custom property
				//$message->setCustomProperty('acme3', array('bing', 'bong'));
				// Set the expiry value to 30 seconds
				//$message->setExpiry(30);
				// Add the message to the message queue
				$push->add($message);
				
				$push->send();
				
				
				
			}

			// Send all messages in the message queue
			
			$aErrorQueue = $push->getErrors();
			
			//print_r($aErrorQueue); die;
			// Disconnect from the Apple Push Notification Service
			$push->disconnect();
		
			// Examine the error message container
			
			if (!empty($aErrorQueue)) {
				// var_dump($aErrorQueue);
			}
			
			return true;
		}
		/** This function is for send push notifications on user iPhone device - End **/
		
		/**
		 *  This function is for send push notifications on user android device - Start. 
		**/
		public function sendAndroidPushNotification($details){
			if(!empty($details))
			{
				$result=array();
				$activityMessage = "You got a private message."; 
				/*MY CUSTOM PUSH NOTIFICATION START */
				//$apiKey="com.cdnsol.cheerwrap"; // for enroot only new
				$apiKey="AIzaSyCnyBOlo5pgFE0fuwIRYPiBQqaBE2JLNzE";
				$url = 'https://android.googleapis.com/gcm/send';
				// Open connection
				$ch = curl_init();
				foreach ($details as $value)
				{
					$deviceId = $value['deviceId'];
					$invitationId = $value['badgeToDoStarCount'];
					$pushMessage = $value['pushMessage'];
					$pushReceiverId = $value['userId'];
					$msgCount=$value['msgCount'];
				/*	$customerName 	= $value['customerName'];
					$customerEmail	= $value['customerEmail'];
					$recipientName	= $value['recipientName']; */
					
					$recipientEmail = $value['recipientEmail'];
					
					$registatoin_ids = array($deviceId);
					$message= array('pushMessage'=>$pushMessage,'msgCount'=>$msgCount,
					'deviceId'=>$deviceId);
					$finalMessage = json_encode($message);
					//activityAction, activityMessage, userId(receiving user)
					
					$fields = array('registration_ids' => $registatoin_ids,'data' => array('message'=>$finalMessage));
					$headers = array('Authorization: key=' . $apiKey,'Content-Type: application/json');
				
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_POST, true);
					curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

					// Disabling SSL Certificate support temporarly
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
					// Execute post
					$result[] = curl_exec($ch);
					
				}
			
					if ($result === FALSE) {
						//die('Curl failed: ' . curl_error($ch));
					} 
					// Close connection
					curl_close($ch);
					/*MY CUSTOM PUSH NOTIFICATION END*/
				
					return $result;
			}
		}
		public function manualNotification($details){
			
				$messagesIds = $details[0]['messagesIds'];
				$deviceId = $details[0]['deviceId'];
				$invitationId = $details[0]['badgeToDoStarCount'];
				$pushReceiverId = $details[0]['userId'];
				$activityMessage = "Private messages";
				/*MY CUSTOM PUSH NOTIFICATION START */
				$apiKey="AIzaSyBqzLGWS_yKf_nL2PILtqJZTxUfaoL2lJ0"; // for enroot only new
				//$apiKey="AIzaSyCRAPvWUne2RdS1uCgcXBTaDzRjESmqqaY"; // for enroot only new tues 4 nov
				$registatoin_ids = array($deviceId);
				$message= array('pushReceiverId'=>$pushReceiverId,'activityAction'=>'PUSH_GEOSENSING','activityMessage'=>$activityMessage,'point'=>$messagesIds);
				$finalMessage = json_encode($message);
				$url = 'https://android.googleapis.com/gcm/send';
				$fields = array('registration_ids' => $registatoin_ids,'data' => array('message'=>$finalMessage));
				$headers = array('Authorization: key=' . $apiKey,'Content-Type: application/json');
				// Open connection
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				// Disabling SSL Certificate support temporarly
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

				// Execute post
				$result = curl_exec($ch);
				if ($result === FALSE) {
					//die('Curl failed: ' . curl_error($ch));
				} 
				// Close connection
				curl_close($ch);
				return $result;//
		}
		/** This function is for send push notifications on user Android device - End **/
	}
