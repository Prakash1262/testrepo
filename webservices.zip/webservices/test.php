<?php
if(isset($_GET['ac']) && $_GET['ac']=='push'){
try{
			// Using Autoload all classes are loaded on-demand
		require_once 'ApnsPHP/Autoload.php';		
		$push = new ApnsPHP_Push(
			ApnsPHP_Abstract::ENVIRONMENT_SANDBOX,
			'ApnsPHP/pushcert.pem'
		);	
		
		///--- Connect push server----	
		$push->connect();
		$msg ='Welcome11';
		$toId ='1';
		$fromId ='1';
		$itemId ='1';
				
			$message = new ApnsPHP_Message('4e4cc75429d0fdad2dda2b48402aa8d3a1689d6d2eb1b2cfe23963bbb529d280');						
			$message->setText($msg);			
			$message->setCustomProperty('message',$msg);						
			$message->setCustomProperty('toId',$toId);			
			$message->setCustomProperty('fromId',$fromId);
			$message->setCustomProperty('itemId',$itemId);
			$message->setSound();
			$message->setExpiry(30);
			$push->add($message);
			
		$data =$push->send();
		///--- Disconnect push server ----	
		$push->disconnect();
		$aErrorQueue = $push->getErrors();
		
		if (!empty($aErrorQueue)) {
			var_dump($aErrorQueue);
		}
		echo "<pre>";print_R($data);
		}catch(Exception $e){
			die("error in ios push.");
		}
die('push test');

}

?>