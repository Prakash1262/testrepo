<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class chat {
    
    public function __construct() {
        /// -- Create Database Connection instance --
        $this->_db      = env::getInst();
        $this->_common  = new commonclass(); /// -- Create get laguage instance --
        
    }
    
    public function chatHistory(){
		$cur_date = date("Y-m-d H:i:s");
		$date 		     = trim($_REQUEST['date']);
		$toId 		     = trim($_REQUEST['toId']);
        $fromId 	     = trim($_REQUEST['fromId']);
        $pId 	     = trim($_REQUEST['itemId']);
        //$date 	     = trim($_REQUEST['date']);
		$where='';
		if($date!=''){
			$where="AND chat.created > '".$date."'";
		}
		$locale = $this->_common->locale();
		$query = ' SELECT chat.* FROM chat ';
		//$query .=' INNER JOIN users ON users.id = chat.fromId';
		$query .=" where (chat.toId = '".$fromId."' OR chat.toId = '".$toId."') ";
		$query .=" AND  (chat.fromId = '".$fromId."' OR chat.fromId = '".$toId."' ) ";
		$query .=" AND chat.itemId = '".$pId."' ".$where." ORDER BY chat.created ASC ";
		$result = $this->_db->my_query_result($query);

		//$count = mysqli_num_rows($result);
		if(count($result) > 0){
			$records_array['status'] = "1";
			$records_array['locale'] = $locale;
			$records_array['locale'] = $locale;
			$records_array['result']    = $result;			
			$records_array['cur_date']    = $cur_date;			
		}else{
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['cur_date'] = $cur_date;			
			$records_array['msg'] = 'No record found.';
		}
		return $records_array;
	} 
	
	public function getChatNotification(){
		$cur_date = date("Y-m-d H:i:s");
		$date 		     = trim($_REQUEST['date']);
		$toId 		     = trim($_REQUEST['userId']);
        
		$where='';
		if($date!=''){
			$where="AND chat.created > '".$date."'";
		}
		$locale = $this->_common->locale();
		$query = ' SELECT chat.*,users.first_name as fromName,product.product_name  FROM chat ';	
                $query .=' INNER JOIN users ON users.id = chat.fromId';
		$query .=' INNER JOIN product ON product.id = chat.itemId';	
		$query .=" where chat.toId = '".$toId."' ";		
		$query .=" ".$where." ORDER BY chat.created ASC ";
		$result = $this->_db->my_query_result($query);

		//$count = mysqli_num_rows($result);
		if(empty($date)){
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['cur_date'] = $cur_date;			
			$records_array['msg'] = 'No record found.';
		}else{
		if(count($result) > 0){
			$records_array['status'] = "1";
			$records_array['locale'] = $locale;			
			$records_array['result']    = $result;			
			$records_array['cur_date']    = $cur_date;			
		}else{
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['cur_date'] = $cur_date;			
			$records_array['msg'] = 'No record found.';
		}
	}
		return $records_array;
	} 
	
	public function chatNotification(){ 
		$cur_date = date("Y-m-d H:i:s");
		$date 		     = trim($_REQUEST['date']);
		$toId 		     = trim($_REQUEST['toId']);
        //$fromId 	     = trim($_REQUEST['fromId']);
        //$pId 	     = trim($_REQUEST['itemId']);
        //$date 	     = trim($_REQUEST['date']);
		$where='';
		if($date!=''){
			$where="AND chat.created > '".$date."'";
		}
		$locale = $this->_common->locale();
                $query = ' SELECT chat.*,users.first_name as fromName,product.product_name FROM chat ';
		$query .=' INNER JOIN users ON users.id = chat.fromId';
		$query .=' INNER JOIN product ON product.id = chat.itemId';
		$query .=" where  chat.toId = '".$toId."' ";		
		$query .="  ".$where." ORDER BY chat.created ASC ";
		$result = $this->_db->my_query_result($query);

		//$count = mysqli_num_rows($result);
		if(count($result) > 0){
			$records_array['status'] = "1";
			$records_array['locale'] = $locale;			
			$records_array['result']    = $result;			
			$records_array['cur_date']    = $cur_date;			
		}else{
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['cur_date'] = $cur_date;
			$records_array['msg'] = 'No record found.';
		}
		return $records_array;
	} 
	
	public function approveChatRequest() {		
		$toId 		     = trim($_REQUEST['toId']);
        $fromId 	     = trim($_REQUEST['fromId']);             
        $itemId 		 = trim($_REQUEST['itemId']);              
        $status 		     = trim($_REQUEST['status']);              
        $locale = $this->_common->locale();
		$permission=true;
		if($toId !='' && $fromId!='' && $itemId!=''){
			$sql  = " Update chat_permission SET ";
			$sql .= " status='".$status."' , ";
			$sql .= " modified='".date('Y-m-d H:i:s')."'";
			$sql .= " WHERE toId='".$toId."'  ";  
			$sql .= " AND fromId='".$fromId."'  ";  
			$sql .= " AND itemId='".$itemId."'  ";
			
			$res=$this->_db->my_query($sql);		                   
			if ($res) {				
				$response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "Save Successfully";                
			}else{
				$response['status']   = "0";
				$response['locale'] = $locale;
				$response['msg'] = "Error! in save.";			
			}
		} else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
	
	public function saveMsg() {		
		$toId 		     = trim($_REQUEST['toId']);
        $fromId 	     = trim($_REQUEST['fromId']);             
        $itemId 		 = trim($_REQUEST['itemId']);              
        $msg 		     = trim($_REQUEST['msg']);              
        $locale = $this->_common->locale();
		$permission=true;
		if($toId !='' && $fromId!='' && $itemId!=''){
			$queryProduct = "SELECT * FROM product where owner_id = '".$fromId."' AND  id = '".$itemId."' ";
			$productResult = $this->_db->my_query($queryProduct);
			$productCount = mysqli_num_rows($productResult);
			if($productCount > 0){
				
			}else{				
				$query = "SELECT * FROM chat_permission where toId = '".$toId."' AND  fromId = '".$fromId."' AND itemId = '".$itemId."' ";
				$result = $this->_db->my_query($query);
				$count = mysqli_num_rows($result);
				if($count > 0){
					$row = $this->_db->my_fetch_object($result);
					if($row->status==0 || $row->status==3 || $row->status==4){
						$permission=false;
					}
				}else{
					$sql  = " INSERT INTO chat_permission SET ";
					$sql .= " toId='".$toId."' , ";  
					$sql .= " fromId='".$fromId."' , ";  
					$sql .= " itemId='".$itemId."' , ";
					$sql .= " status='0' , ";
					$sql .= " created='".date('Y-m-d H:i:s')."'";
					$this->_db->my_query($sql);	
				}
			}
			
			if($permission==true){
					$sql  = " INSERT INTO chat SET ";
					$sql .= " toId='".$toId."' , ";  
					$sql .= " fromId='".$fromId."' , ";  
					$sql .= " itemId='".$itemId."' , ";
					$sql .= " msg='".$msg."' , ";
					$sql .= " created='".date('Y-m-d H:i:s')."'";
					$this->_db->my_query($sql);
					$Id = $this->_db->my_query_id();                   
					if ($Id) {	
						$this->sendPush($toId,$msg,$fromId,$itemId);
						$response['id'] = $Id;
						$response['status']   = "1";
						$response['locale'] = $locale;
						$response['msg'] = "Save Successfully";                
					}else{
						$response['status']   = "0";
						$response['locale'] = $locale;
						$response['msg'] = "Error! in save.";			
					}
			}else{
				$response['status']   = "0";
				$response['locale'] = $locale;
				$response['msg'] = ($row->status==0?"Client not approved your chat request.":($row->status==3?"Client reject your request.":"Client not blocked you."));			
			}
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
    	
	function myChatRequest(){
		$locale = $this->_common->locale();
		$userId = $_REQUEST['user_id'];

		$query ='SELECT distinct concat(chat.itemId,"_",chat.fromId) as chat_product_id,chat_permission.*, users.first_name as fName,tu.first_name as tName ,users.email,product.owner_id,product.product_name,chat.msg,chat.created,chat.isRead';
		$query .=' FROM chat_permission';
		$query .=' INNER JOIN chat ON (chat.fromId = chat_permission.fromId AND chat.itemId = chat_permission.itemId)';
		$query .=' INNER JOIN product ON product.id = chat_permission.itemId';
		$query .=' INNER JOIN users ON users.id = chat_permission.fromId';
		$query .=' INNER JOIN users as tu ON tu.id = chat_permission.toId';		
		$query .=' WHERE (chat_permission.toId="'.$userId.'" OR chat_permission.fromId="'.$userId.'")';
		$query .=' AND (chat.toId="'.$userId.'" OR chat.fromId="'.$userId.'")';
		$query .=' GROUP BY concat(chat.itemId,"_",chat.fromId)';
		$query .=' ORDER BY chat.created DESC';
		
		$result = $this->_db->my_query_result($query);
		if(count($result) > 0){	
			$records_array['status'] = "1";	
			$records_array['locale'] = $locale;
			$records_array['result']    = $result;
		}else{
			$records_array['status'] = "0";	
			$records_array['locale'] = $locale;
			$records_array['msg'] = 'No record found.';	
		}	
		return $records_array;
	}
	
	public function sendPush($userId,$msg,$fromId,$itemId){
		include("push/ApnsPHP/Autoload.php");
		$query ='SELECT * from users';	
		$query .=' WHERE id="'.$userId.'"';	
		$result = $this->_db->my_query_result($query);
		if(count($result) > 0){	
			if($result[0]['deviceType']==0){
				$result[0]['deviceToken'];
				$this->androidPush($result[0]['deviceToken'],$msg,$userId,$fromId,$itemId);
			}else if($result[0]['deviceType']==1){
				$this->androidPush($result[0]['deviceToken'],$msg,$userId,$fromId,$itemId);
			}
		}	
	}
	
	public function testPush(){
		include("push/ApnsPHP/Autoload.php");
		$deviceToken=$_REQUEST['d'];
		//echo "<br>";		
		//$this->androidPush($deviceToken,'hi',1,1,1);
		$this->iosPush($deviceToken,'hi',1,1,1);
echo $deviceToken;
		die("dddd");
	}
	
	
	public function androidPush($device_token,$message,$toId,$fromId,$itemId){
		try{
			$urls[]= 'https://android.googleapis.com/gcm/send';        
			$bundle=array(
				'message' => $message,
				'toId' => $toId,
				'fromId' => $fromId,
				'itemId' => $itemId
			);

			$device_Arr=array();
			$device_Arr[]=$device_token;
			//Send Push
			$data[]=array('data' => $bundle,'registration_ids' => $device_Arr);
			$response=$this->MultiRequests($urls,$data);
			//print_r($response);
		}catch(Exception $e){
			die("error in android push.");
		}
	}

	public function iosPush($device_token,$message,$toId,$fromId,$itemId){
		try{
			// Using Autoload all classes are loaded on-demand
			require_once 'push/ApnsPHP/Autoload.php';					
			$push = new ApnsPHP_Push(
				ApnsPHP_Abstract::ENVIRONMENT_SANDBOX,
				'push/ApnsPHP/pushcert.pem'
			);		
			///--- Connect push server----		
			$push->connect();	
			$pushMessage = new ApnsPHP_Message($device_token);
			$pushMessage->setText($message);
			$pushMessage->setCustomProperty('message',$message);						
			$pushMessage->setCustomProperty('toId',$toId);			
			$pushMessage->setCustomProperty('fromId',$fromId);
			$pushMessage->setCustomProperty('itemId',$itemId);
			$pushMessage->setSound();
			$pushMessage->setExpiry(30);			
			$push->add($pushMessage);
			///--- Send iOS push----	
			$push->send();	
			///--- Disconnect push server ----	
			$push->disconnect();
			$aErrorQueue = $push->getErrors();
			if (!empty($aErrorQueue)) {
				var_dump($aErrorQueue);
			}
		}catch(Exception $e){
			die("error in ios push.");
		}
	}

	
	/*------------------------------------------------------------
	 | Function for send curl multipal request simultanousaly
	 ------------------------------------------------------------*/
	public function MultiRequests($urls , $data) {
		$curlMultiHandle = curl_multi_init();

		$curlHandles = array();
		$responses = array();

		foreach($urls as $id => $url) {
			$curlHandles[$id] = $this->CreateHandle($url , $data[$id]);
			curl_multi_add_handle($curlMultiHandle, $curlHandles[$id]);
		}

		$running = null;
		do {
			curl_multi_exec($curlMultiHandle, $running);
		} while($running > 0);

		foreach($curlHandles as $id => $handle) {
			$responses[$id] = curl_multi_getcontent($handle);
			curl_multi_remove_handle($curlMultiHandle, $handle);
		}
		curl_multi_close($curlMultiHandle);

		return $responses;
	}
	/*--------------------------------------------------------------
	 | Initiate Function for send curl multipal request simultanousaly
	 ----------------------------------------------------------------
	*/
	public function CreateHandle($url , $data) {
		$curlHandle = curl_init($url);
		$headers = array("Content-Type: application/json", "Authorization: key=AAAADjgIlEw:APA91bFiU6Yp6asZjAxc532Fz2sL7kqQD5RHdk40K7XsRt0youUj7QMv2A0uNjXgQHDR9GUUncjLmZHj57IAcjS6Qq9DJam2XVq8sUnIHrUEzU0xFrUEJsH_GOuUzCxgVZICNtlIYagn");		
		$defaultOptions = array (
			CURLOPT_HTTPHEADER =>$headers,		
			CURLOPT_ENCODING => "gzip" ,
			CURLOPT_FOLLOWLOCATION => true ,
			CURLOPT_RETURNTRANSFER => true ,
			CURLOPT_POST => 1,
			CURLOPT_POSTFIELDS => json_encode($data)
		);

		curl_setopt_array($curlHandle , $defaultOptions);
		
		return $curlHandle;
	}

	/*---------------------------------------------------------------------------
	*@manageCurlRequest() function to call client API on given url and parameter
	*--------------------------------------------------------------------------- */
	public function manageCurlRequest($url='',$postData='',$header='') {
		$ch = curl_init();  
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		if($header!=''){
			curl_setopt($ch, CURLOPT_HTTPHEADER,$header); 	
			curl_setopt($ch, CURLOPT_HEADER, true); 
		}else{
			curl_setopt($ch, CURLOPT_HEADER, false); 
		}
		curl_setopt($ch, CURLOPT_POST, count($postData));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);    
		$output=curl_exec($ch);
		curl_close($ch);
		return $output;
	} //end manageCurlRequest()	
}
?>
