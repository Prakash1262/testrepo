<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
	/**
	 * Author : CDNSOL
	 * Email  : admin@cdnsol.com
	 * Timestamp : Aug-8 04:29 PM
	 * Copyright : www.cdnsol.com
	 */
	
	/** Fetch the email template as per the post purpose and language
	 * Return the email template data from enr_email_template table.
	 * **/
	function get_email_template($purpose,$language)
	{
		mysql_query("SET NAMES 'UTF8'");
		$sql = "SELECT * FROM `enr_email_template` WHERE `purpose` = '$purpose' AND `language` = '$language'";
		$result = mysql_query($sql); 
		mysql_set_charset("UTF8", $result);
		$row = mysql_fetch_array($result);
		$newData = $row[2]."||".$row[3];	
		return $newData;
	}
	
	/* This function give user details by user_id - return user_data */  
    function getUserInformation($userId)
    {
		header("Content-type: text/html; charset=utf-8");
		mysql_query("SET NAMES 'UTF8'");
		$UserDetailSql="SELECT * FROM `enr_users` WHERE id='".$userId."'";
		$UserDetailSqlVal = mysql_query($UserDetailSql);
		mysql_set_charset("UTF8", $UserDetailSqlVal);
		$UserDetailResult = mysql_fetch_object($UserDetailSqlVal);
		return $UserDetailResult;
	}
	/** Get User details - End **/
	
	function sendActivationMailAction($senderId,$receiverId,$purpose,$language,$activityType, $otherData)
	{
		require_once("class.phpmailer.php");
		$mail = new PHPMailer();
		$mail->IsSMTP();                 	// set mailer to use SMTP
		$mail->SMTPAuth = true;     		// turn on SMTP authentication
		$mail->CharSet="windows-1251";
		$mail->CharSet="utf-8";
		$mail->WordWrap = 50;      			// set word wrap to 50 characters
		$mail->IsHTML(true); 
		
		switch ($activityType) {
			
			case "activationCode":
					$randomActivationCode = $otherData; //random Activation Code passes in groupName parameter from function.
					$emailid = $receiverId;
					$user_name = $senderId;
					$mail->AddAddress($emailid,$user_name);	//sender user email id
					
					$site_url=URL_PATH."users/newpassword.php?id=".$randomActivationCode;
					$message = "<a href=".$site_url.">Here</a>";
					
					$refundTemplate = get_email_template('Activation Code','en');
					$refundTemplateNew = explode("||",$refundTemplate);
					
					$searchArray = array("{user_name}","{here}");
					$replaceArray = array($user_name, $message);
					$refundTemplateSubject = $refundTemplateNew[0];
					$refundTemplateBody = $refundTemplateNew[1];
					$refurndTmailBody=str_replace($searchArray, $replaceArray, $refundTemplateBody);
					$mail->Subject = $refundTemplateSubject;
					$mail->Body    = $refurndTmailBody;
					$mail->send();
					break;
					
			case "forgotPassword":
					$hashedPassword = $otherData; //hashed password passes in groupName parameter from function.
					$emailid = $receiverId;
					$user_name = $senderId;
					$mail->AddAddress($emailid,$user_name);	//sender user email id
					
					$forgot_site_url=URL_PATH."users/resetpassword.php?id=".$hashedPassword;
					$message = "<a href=".$forgot_site_url.">here</a>";
					$refundTemplate = get_email_template('Reset password','en');
					$refundTemplateNew = explode("||",$refundTemplate);
					$searchArray = array("{user_name}","{here}");
					$replaceArray = array($user_name, $message);
					$refundTemplateSubject = $refundTemplateNew[0];
					$refundTemplateBody = $refundTemplateNew[1];
					$refurndTmailBody=str_replace($searchArray, $replaceArray, $refundTemplateBody);
					$mail->Subject = $refundTemplateSubject;
					$mail->Body    = $refurndTmailBody;
					$mail->send();
					break;
		}
	}
?>
