<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class userprofile {
    
    /* IMAGE URL CONSTANT	
     * @method __construct
     * @see private constructor to protect beign inherited
     * @access private
     * @return void
     * M = MANDATORY, NM = NOT-MANDATORY, H = HARDCODED
     */
    
    public function __construct() {
        /// -- Create Database Connection instance --
        $this->_db      = env::getInst();
        $this->_common  = new commonclass(); /// -- Create get laguage instance --
        $records_array  = array();
        $records_array1 = array();
       
    }
    
    /**
     * @method : checkEmailExist => check contact email exist or not.
     * @param :  emailid
     * @return : check contact email exist or not.
     */
    public function checkEmailExist($emailid) 
    {
		$locale  = $this->_common->locale();
        if ($emailid != "") {
			$result = $this->_common->getUserDetailsByEmailId($emailid);
			if (!empty($result)) {
				if(!empty($emailid)){
					$records_array['msg']    = $this->_common->langText($locale, 'txt.registration.email.address.available');
				}
            } 
        } 
        return $records_array;
    }
    
	/**
     * @method : getUserInformation => Get profile information of user. 
     * @param :  loginUserId(M)
     * @return : Profile information of user.
     */
    function getUserInformation() {
        $loginUserId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:''); // mandatary parameter.
        $locale      = $this->_common->locale();
        if ($loginUserId != "") {
            $this->_db->my_query("SET NAMES 'UTF8'");
            $sql_get_user = "SELECT * FROM users where `id`='" . $loginUserId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            //mysql_set_charset("UTF8", $get_user);
            $row = $this->_db->my_fetch_object($get_user);
          
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				if(!empty($row->country_id)){
				 $records_array['country_name'] = $this->getCountryNameById($row->country_id);
				 }else{
				 $records_array['country_name']="";
				 }
				if(!empty($row->state_id)){
				$records_array['state_name'] = $this->getStateNameById($row->state_id);
				}else{
				$records_array['state_name']="";
				}
				if(!empty($row->city_id)){
				$records_array['city_name'] = $this->getCityNameById($row->city_id);
				}else{
				$records_array['city_name']="";
				}
				$records_array['userId'] = $row->id;
                $records_array['first_name'] = (!empty($row->first_name))?$row->first_name:'';
                $records_array['email'] = (!empty($row->email))?$row->email:'';
                $records_array['mobile_phone'] = (!empty($row->mobile_phone))?$row->mobile_phone:'';
                $records_array['lat'] = (!empty($row->lat))?$row->lat:'';
                $records_array['long'] = (!empty($row->long))?$row->long:'';
                $records_array['address'] =(!empty($row->address))?$row->address:'';
                $records_array['createDate'] = (!empty($row->created_at))?$row->created_at:'';
                $records_array['last_logged_in'] = (!empty($row->last_logged_in))?$row->last_logged_in:'';
				$records_array['country'] = (!empty($row->country_id))?$row->country_id:'';
				$records_array['state'] = (!empty($row->state_id))?$row->state_id:'';
				$records_array['city'] = (!empty($row->city_id))?$row->city_id:'';
                $userImage   = $row->profile_image;
				if (strpos($userImage, 'http') !== false) {
				$records_array['image_url'] = $userImage;
				}else{
					if ($userImage != '') {
						$records_array['image_url'] = USER_FOLDER_PATH.$userImage;
					}else {
						$imgName = "no_img.png";
						$records_array['image_url'] = USER_FOLDER_PATH.$imgName;
					}
               }
			   
				$records_array['status'] = "1";
                $records_array['msg']    = $this->_common->langText($locale, 'txt.common.user.info.get.successfully');
                $records_array['locale'] = $locale;
            } else {
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'txt.common.user.id.not.registered');
            }
        } else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
		return $records_array;
    }
     /**
     * @method : getCountry
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getCountry() 
    {        
        $result='';
        $locale  = $this->_common->locale();
		$result11 = $this->_common->getUserDetails(0);
		$query = "SELECT country_id,country_name FROM country"; 		
		$result = $this->_db->my_query_result($query);			
		if(!empty($result)){
			$records_array['status'] = "1";
			$records_array['data'] = $result;
			$records_array['locale'] = $locale;
			$records_array['msg']    = $this->_common->langText($locale, 'get_country_success');
		}else{
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
		}
        return $records_array;
    }
	/**
     * @method : getCountryNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getCountryNameById($id="") 
    {
        if (!empty($id)) {
			$query = "SELECT country_name FROM country WHERE country_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysqli_set_charset("UTF8", $res);
            $name=$res[0]['country_name'];
		}	
		return $name;
    }
	/**
     * @method : getStateNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
     public function getStateNameById($id="") 
    {
         if (!empty($id)) {
			$query = "SELECT state_name FROM state WHERE state_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['state_name'];
		}	
        return $name;
    }
	/**
     * @method : getCityNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
   public function getCityNameById($id="") 
    {
        if (!empty($id)) {
			$query = "SELECT city_name FROM city WHERE city_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['city_name'];
		}	
        return $name;
    }
	/**
     * @method : getStateByCountryId
     * @param :  countryId
     * @return : array
     */
    public function getStateByCountryId() 
    {	
        $countryId = trim($_REQUEST['countryId']);
        $result='';
        $locale  = $this->_common->locale();
		//$result = $this->_common->getUserDetails($userId);
		
        if (!empty($countryId)) {
			$query = "SELECT state_id,state_name FROM state WHERE country_id = '".$countryId."' ORDER BY state_name ASC"; 
            $res = $this->_db->my_query_result($query);
            mysql_set_charset("UTF8", $res);
            $result = $this->_db->my_query_result($query);
            if(!empty($result)){
                $records_array['status'] = "1";
                $records_array['data'] = $result;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_state_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        }else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    }
	/**
     * @method : getCityByStateId
     * @param :  stateId
     * @return : array
     */
    public function getCityByStateId() 
    {	
        $stateId = trim($_REQUEST['stateId']);
        $result='';
        $locale  = $this->_common->locale();
		//$result = $this->_common->getUserDetails($userId);
		
        if (!empty($stateId)) {
			$query = "SELECT city_id,city_name FROM city WHERE state_id = '".$stateId."' ORDER BY city_name ASC"; 
            $res = $this->_db->my_query_result($query);
            mysql_set_charset("UTF8", $res);
            $result = $this->_db->my_query_result($query);
            if(!empty($result)){
                $records_array['status'] = "1";
                $records_array['data'] = $result;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_city_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        }else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    }
    
    
    //End function addUserContactList.
    
    
    
    //End function addUserContactList.
    /**
     * @method : updateUserProfile => update profile information of user. 
     * @param :  loginUserId(M), firstName(M), lastName(M), image_url(NM), mobile(M)
     * @return : Update Profile information of user.
     */
	 
    function updateUserProfile() {
		$loginUserId 	= (isset($_REQUEST['userId'])?$_REQUEST['userId']:''); // mandatary parameter.
        $name  	        = (isset($_REQUEST['name'])?$_REQUEST['name']:'');
        $mobile_phone  	= (isset($_REQUEST['contact'])?$_REQUEST['contact']:'');
        $image_url	= (isset($_REQUEST['image_url'])?$_REQUEST['image_url']:'');
		$country        = (isset($_REQUEST['country'])?$_REQUEST['country']:'');
		$state           = (isset($_REQUEST['state'])?$_REQUEST['state']:'');
		$city           = (isset($_REQUEST['city'])?$_REQUEST['city']:'');
		$address        = (isset($_REQUEST['address'])?$_REQUEST['address']:'');
		$lat        = (isset($_REQUEST['lat'])?$_REQUEST['lat']:'');
		$long        = (isset($_REQUEST['long'])?$_REQUEST['long']:'');
		$status = 1;
        $locale = $this->_common->locale();
        if ($loginUserId != "") {
            $this->_db->my_query("SET NAMES 'UTF8'");
            $sql_get_user = "SELECT * FROM users where `id`='" . $loginUserId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
			$row = $this->_db->my_fetch_object($get_user);
			if ($this->_db->my_num_rows($get_user) > 0) 
            {
			/***** Update user profile information - Start ********** */
			
			$parameter = '';
			if($status !=''){
				$parameter .= " status = '".$status."'" ;
			}
			if($name !=''){
				$parameter .= " ,first_name = '".$name."'" ;
			}
			if($mobile_phone !=''){
				$parameter .= " ,mobile_phone = '".$mobile_phone."'" ;
			}
			if($country !=''){
				$parameter .= " ,country_id = '".$country."'" ;
			}
			if($state !=''){
				$parameter .= " ,state_id = '".$state."'" ;
			}
			if($city !=''){
				$parameter .= " ,city_id = '".$city."'" ;
			}
			if($address !=''){
				$parameter .= " ,address = '".$address."'" ;
			}
			if($lat !=''){
				$parameter .= " ,lat = '".$lat."'" ;
			}
			if($long !=''){
				$parameter .= " ,`long` = '".$long."'" ;
			}
			if(!empty($image_url)){
				$folder = USER_UPLOAD_PATH;
				$imgByteArr = $_REQUEST['image_url'];      
				$image_url= $this->imageUpload($imgByteArr,$folder);
				$parameter .= " ,profile_image = '".$image_url."'" ;
			}
				$where .= ' where id = "'.$loginUserId.'"';
				$sql_get_user = 'UPDATE users SET '.$parameter.$where;
				$update   = $this->_db->my_query($sql_get_user);
				$UserDetails = $this->_common->getUserDetails($loginUserId);
				
				if(!empty($UserDetails->country_id)){
				 $records_array['country_name'] = $this->getCountryNameById($UserDetails->country_id);
				 }else{
				 $records_array['country_name']="";
				 }
				if(!empty($UserDetails->state_id)){
				$records_array['state_name'] = $this->getStateNameById($UserDetails->state_id);
				}else{
				$records_array['state_name']="";
				}
				if(!empty($UserDetails->city_id)){
				$records_array['city_name'] = $this->getCityNameById($UserDetails->city_id);
				}else{
				$records_array['city_name']="";
				}
				
				$records_array['userId'] = $UserDetails->id;
				$records_array['name'] = (!empty($UserDetails->first_name))?$UserDetails->first_name:'';
                $records_array['email'] = (!empty($UserDetails->email))?$UserDetails->email:'';
                $records_array['mobile_phone'] =(!empty($UserDetails->mobile_phone))?$UserDetails->mobile_phone:'';
                $records_array['country'] = (!empty($UserDetails->country_id))?$UserDetails->country_id:'';
                $records_array['state'] = (!empty($UserDetails->state_id))?$UserDetails->state_id:'';
				$records_array['city'] = (!empty($UserDetails->city_id))?$UserDetails->city_id:'';
                $records_array['address'] = (!empty($UserDetails->address))?$UserDetails->address:'';
                $records_array['lat'] = (!empty($UserDetails->lat))?$UserDetails->lat:'';
                $records_array['long'] = (!empty($UserDetails->long))?$UserDetails->long:'';
                $records_array['is_email_verify'] = $row->is_email_verify;
				$userImage   = $row->profile_image;
				if (strpos($userImage, 'http') !== false) {
				$records_array['image_url'] = $userImage;
				}else{
					if ($userImage != '') {
						$records_array['image_url'] = USER_FOLDER_PATH.$userImage;
					}else {
						$imgName = "no_img.png";
						$records_array['image_url'] = USER_FOLDER_PATH.$imgName;
					}
               }
                $records_array['status'] = "1";
                $records_array['msg']    = $this->_common->langText($locale, 'txt.user.info.updated.successfully');
                $records_array['locale'] = $locale;
            } else {
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'txt.common.user.id.not.registered');
            }
        } else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    }
	
	
	
	function changePassword() {
		$loginUserId 	= (isset($_REQUEST['userId'])?$_REQUEST['userId']:''); // mandatary parameter.
        $oldPassword  	= (isset($_REQUEST['oldPassword'])?$_REQUEST['oldPassword']:'');
        $newPassword    = (isset($_REQUEST['newPassword'])?$_REQUEST['newPassword']:'');
        
        $locale = $this->_common->locale();
        if ($loginUserId != "") {
            $this->_db->my_query("SET NAMES 'UTF8'");
            $sql_get_user = "SELECT * FROM users where `id`='" . $loginUserId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
            if ($this->_db->my_num_rows($get_user) > 0) 
            {	
				$UserDetails = $this->_common->getUserDetails($loginUserId);
				if($UserDetails->password == md5($oldPassword)){
                
                $sql_get_user = "UPDATE users SET `password`='" . md5($newPassword) . "' WHERE `id`= '".$loginUserId."'";
				$update   = $this->_db->my_query($sql_get_user);
				 $records_array['status'] = "1";
                $records_array['msg']    = $this->_common->langText($locale, 'txt.change.password');
                $records_array['locale'] = $locale;
            } else {
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'txt.old.password.validation');
            }}
        } else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    
 }
 /**
    * @This function use for imageupload
    * @Input: 
    * @output: return message and status
    * @access public
    */  
    public function imageUpload($encoded_image=null,$upload_path) {
		$decoded_image = base64_decode($encoded_image);
		$f = finfo_open();
        $mime_type = finfo_buffer($f, $decoded_image, FILEINFO_MIME_TYPE);
		$file_type = explode('/', $mime_type);
        if(!empty($file_type[1])){
            $ext = $file_type[1];
        }else{
            $ext = 'png';
        }
        
        $imgname       = md5(uniqid()) . '.'.$ext;
        $ret =  file_put_contents($upload_path."". $imgname, $decoded_image);
        $actual       = $upload_path ."" .$imgname; // Set the actual image name
        
		return $imgname;
    }
    //Function getUserInformation by logged in user - End......
    
     

    //Function getUserInformation by logged in user - End......
}
?>
