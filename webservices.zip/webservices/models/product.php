<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class product {
    
    public function __construct() {
        /// -- Create Database Connection instance --
        $this->_db      = env::getInst();
        $this->_common  = new commonclass(); /// -- Create get laguage instance --
        
    }
	
	 /**
     * @method : productImages
     * @param :  productId
     * @return : array
     */ 
	 public function productImageDelete(){		
		$productId = $_REQUEST['productId'];
		$imageUrl = $_REQUEST['imageUrl'];		
		if($productId!='' && $imageUrl!=''){	
			$imageArr = explode('/',$imageUrl);
			$image =$imageArr[count($imageArr)-1];
			$query = "delete from product_image where `product_id`= '".$productId."' and `image_url`= '".$image."'";
			$result = $this->_db->my_query($query);
		}
		//die;
		$locale  = $this->_common->locale();
		$records_array['status'] = "1";
                $records_array['imageUrl'] = $imageUrl;
		$records_array['locale'] = $locale;
		$records_array['msg']    = $this->_common->langText($locale, 'image.delete');
		return $records_array;
	} 
	
     /**
     * @method : productImages
     * @param :  productId
     * @return : array
     */ 
	 public function productImages(){
		 //print_r($_REQUEST);die;
		$productId = $_REQUEST['productId'];
		$image_array = $_REQUEST['images'];
		//echo count($image_array);
		if(count($image_array)>0){		
			foreach($image_array as $res){
				$folder = PRODUCT_UPLOAD_PATH;
				$imgByteArr = $res;      
				$image_url= $this->imageUpload($imgByteArr,$folder);
				$query = "INSERT INTO product_image SET `image_url` = '".$image_url."',`text` = '".$image_url."',`product_id`= '".$productId."',created_date='".date('Y-m-d h:i:s')."'";
				$result = $this->_db->my_query_result($query);
			}
		}
		//die;
		$locale  = $this->_common->locale();
		$records_array['status'] = "1";

		$records_array['locale'] = $locale;
		$records_array['msg']    = $this->_common->langText($locale, 'listdetail.get.sucess');
		return $records_array;
	} 
	 
	 /**
     * @method : productImages
     * @param :  productId
     * @return : array
     */ 
	 public function addProductImages(){
		 //print_r($_REQUEST);die;
		$productId = $_REQUEST['productId'];
		$image = $_REQUEST['image'];
                $image_url='';
		if($productId!='' && $image!=''){				
			$folder = PRODUCT_UPLOAD_PATH;
			$imgByteArr = $image;      
			$image_url= $this->imageUpload($imgByteArr,$folder);
			$query = "INSERT INTO product_image SET `image_url` = '".$image_url."',`text` = '".$image_url."',`product_id`= '".$productId."',created_date='".date('Y-m-d h:i:s')."'";
			$result = $this->_db->my_query_result($query);	
			
			$locale  = $this->_common->locale();
			
			$records_array['status'] = "1";
	                $records_array['imageUrl'] = product_FOLDER_PATH.$image_url;
			$records_array['locale'] = $locale;
			$records_array['msg']    = $this->_common->langText($locale, 'listdetail.get.sucess');		
		}else{
			$locale  = $this->_common->locale();
			$records_array['status'] = "0";
			$records_array['locale'] = $locale;
			$records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
		}		
		
		return $records_array;
	} 
	 /**
     * @method : getcategory
     * @param :  userId
     * @return : array
     */
    public function getCategory() 
    {	$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT *  FROM categories WHERE status = 1"; 
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				foreach ($result as $key=>$res){
					$res['image']=category_FOLDER_PATH.$res['category_image'];
				}
				$result[$key]['image']=$res['image'];
				
				$records_array['status'] = "1";
                $records_array['data'] = $result;
				$records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_category_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        
        return $records_array;
    }
	
	
	/**
     * @method : getEnquiryList
     * @param :  userId
     * @return : array
     */
    public function getEnquiryList() 
    {	
		$userId    = trim($_REQUEST['userId']);
		$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT enquiry.*,product.id as productID,product.product_name FROM enquiry LEFT JOIN product ON product.id= enquiry.product_id LEFT JOIN users ON users.id= product.owner_id  WHERE  users.id = '".$userId."'"; 
		
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$records_array['status'] = "1";
                $records_array['data'] = $result;
				$records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_enquiry_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        
        return $records_array;
    } 
	/**
     * @method : deleteEnquiry
     * @param :  userId
     * @param :  productId
     * @return : array
     */
    public function deleteEnquiry() 
    {	
		$id = (isset($_REQUEST['id'])?$_REQUEST['id']:'');
		$result='';
        $locale  = $this->_common->locale();
		if($id !=''){
			$query = "DELETE FROM enquiry WHERE id = '".$id."'"; 
			$result = $this->_db->my_query_result($query);	
			$records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'enquiry.delete.sucess');
		}else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
			
		}
        return $records_array;
    }
	/**
     * @method : getSubCategory
     * @param :  userId
     * @return : array
     */
    public function getSubCategory() 
    {	$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT *  FROM subcategory WHERE status = 1"; 
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$records_array['status'] = "1";
                $records_array['data'] = $result;
				$records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_subcategory_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        
        return $records_array;
    } 
	
	/**
     * @method : getTestimonial
     * @param :  userId
     * @return : array
     */
    public function getTestimonial() 
    {	
	$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT *  FROM testimonial WHERE is_active = 1";
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$dataArr=array();
				foreach ($result as $key=>$res){
					
					$dataArr[$key+1]['id']=$res['id'];
					$dataArr[$key+1]['title']= ucfirst($res['title']);
					$dataArr[$key+1]['content']= htmlspecialchars($res['content']);
					$dataArr[$key+1]['created_by']=$res['created_by'];
					$dataArr[$key+1]['add_date']=$res['add_date'];
					}
					
				$records_array['status'] = "1";
                $records_array['data'] = $dataArr;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_testimonial_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_testimonial_error');
            }
        return $records_array;
    }
	
	/**
     * @method : getServices
     * @param :  userId
     * @return : array
     */
    public function getServices() 
    {	
	$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT *  FROM services WHERE status = 1";
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$dataArr=array();
				foreach ($result as $key=>$res){
					
					$dataArr[$key+1]['id']=$res['id'];
					$dataArr[$key+1]['title']= ucfirst($res['title']);
					$dataArr[$key+1]['description']= htmlspecialchars($res['description']);
					$dataArr[$key+1]['image']=service_FOLDER_PATH.$res['logo'];
					}
					
				$records_array['status'] = "1";
                $records_array['data'] = $dataArr;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_service_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_service_error');
            }
        return $records_array;
    }
	
	/**
     * @method : getFaq
     * @param :  userId
     * @return : array
     */
    public function getFaq() 
    {	
		$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT *  FROM faq WHERE is_active = 1";
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$dataArr=array();
				foreach ($result as $key=>$res){
					$dataArr[$key+1]['id']=$res['id'];
					$dataArr[$key+1]['faq_ques']= ucfirst($res['faq_ques']);
					$dataArr[$key+1]['faq_ans']= htmlspecialchars($res['faq_ans']);
					}
					
				$records_array['status'] = "1";
                $records_array['data'] = $dataArr;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_testimonial_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_testimonial_error');
            }
			
        return $records_array;
    }
	
	/**
     * @method : getContactUS
     * @param :  userId
     * @return : array
     */
    public function getContactUS() 
    {	
		$locale  = $this->_common->locale();
		$query = "SELECT *  FROM pages WHERE id = 4"; 
        $result = $this->_db->my_query_result($query);
		$records_array['content'] = $result[0]['body'];
		$records_array['status'] = "1";    
		$records_array['locale'] = $locale;		
        $records_array['msg']    = $this->_common->langText($locale, 'success');    
		return $records_array;
    }
	
	/**
     * @method : getAboutUs
     * @param :  userId
     * @return : array
     */
    public function getAboutUs() 
    {	
		$locale  = $this->_common->locale();
		$query = "SELECT *  FROM pages WHERE id = 1"; 
        $result = $this->_db->my_query_result($query);
		$records_array['content'] = $result[0]['body'];
		$records_array['status'] = "1"; 
		$records_array['locale'] = $locale;		
        $records_array['msg']    = $this->_common->langText($locale, 'success');      
		return $records_array;
    }
	
	/**
     * @method : getAboutUs
     * @param :  userId
     * @return : array
     */
    public function getPrivacyPolicy() 
    {	
		$locale  = $this->_common->locale();
		$query = "SELECT *  FROM pages WHERE id = 2"; 
        $result = $this->_db->my_query_result($query);
		
		$records_array['content'] = $result[0]['body'];
		$records_array['status'] = "1"; 
		$records_array['locale'] = $locale;		
        $records_array['msg']    = $this->_common->langText($locale, 'success');      
		return $records_array;
    }
	
	/**
     * @method : getAboutUs
     * @param :  userId
     * @return : array
     */
    public function getTerms() 
    {	
		$locale  = $this->_common->locale();
		$query = "SELECT *  FROM pages WHERE id = 3"; 
        $result = $this->_db->my_query_result($query);
		$records_array['content'] = $result[0]['body'];		
		$records_array['status'] = "1"; 
		$records_array['locale'] = $locale;		
        $records_array['msg']    = $this->_common->langText($locale, 'success');      
		return $records_array;
    }
	
	   /**
     * @method : getcategoryById
     * @param :  userId
	 * @param :  categoryId
     * @return : array
     */
    public function getcategoryById() 
    {
        $cId    = trim($_REQUEST['categoryId']);
        $result  ='';
        $locale  = $this->_common->locale();
		if (!empty($cId)) {
			$query = "SELECT *  FROM categories WHERE status = 1 AND id = '".$cId."'"; 
            $result = $this->_db->my_query_result($query);
			foreach ($result as $key=>$res){
				$result[$key]['category_image']=category_FOLDER_PATH.$res['category_image'];
			}
            if(!empty($result)){
                $records_array['status'] = "1";
                $records_array['data'] = $result;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_category_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        }else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    } 
	
	/**
     * @method : getcategoryById
     * @param :  userId
	 * @param :  categoryId
     * @return : array
     */
    public function getSubCategoryById() 
    {
        $sId    = trim($_REQUEST['subCategoryId']);
        $result  ='';
        $locale  = $this->_common->locale();
		if (!empty($sId)) {
			$query = "SELECT *  FROM subcategory WHERE status = 1 AND category_id = '".$sId."'"; 
            $result = $this->_db->my_query_result($query);
			if(!empty($result)){
                $records_array['status'] = "1";
                $records_array['data'] = $result;
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_subcategory_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        }else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    }
	
	
	
	/**
     * @method : listProduct
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
	 
    public function listProduct() 
    {	
        $userId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$categoryId = (isset($_REQUEST['categoryId'])?$_REQUEST['categoryId']:'');
		$subCategoryId = (isset($_REQUEST['subCategoryId'])?$_REQUEST['subCategoryId']:'');
		$title = (isset($_REQUEST['title'])?$_REQUEST['title']:'');
		$price = (isset($_REQUEST['price'])?$_REQUEST['price']:'');
		$productType = (isset($_REQUEST['productType'])?$_REQUEST['productType']:'');
		$countryId = (isset($_REQUEST['countryId'])?$_REQUEST['countryId']:'');
		$stateId = (isset($_REQUEST['stateId'])?$_REQUEST['stateId']:'');
		$cityId = (isset($_REQUEST['cityId'])?$_REQUEST['cityId']:'');
		$status = (isset($_REQUEST['status'])?$_REQUEST['status']:1);
		$page = (isset($_REQUEST['page'])?$_REQUEST['page']:1);
		$all = (isset($_REQUEST['all'])?$_REQUEST['all']:0);
		$lat = (isset($_REQUEST['lat'])?$_REQUEST['lat']:'');
		$lng = (isset($_REQUEST['lng'])?$_REQUEST['lng']:'');
		$distance = (isset($_REQUEST['distance'])?$_REQUEST['distance']:'');
		$subQuery = '';
		
		$offset = 10 * ($page -1);
		$result='';
        $locale  = $this->_common->locale();
		
		$selectQ='';
		$selectH='';
		if($lat !='' && $lng !='' && $distance!= ''){ 
			$selectH=' HAVING distance <= '.$distance;
			$selectQ=' ,(((acos(sin(('.$lat.'*pi()/180)) * sin(('.$lat.'*pi()/180))+cos(('.$lat.'*pi()/180)) * cos((product.lat*pi()/180)) * cos((('.$lng.'- product.long)*pi()/180))))*180/pi())*60*1.1515*1.609344)/1000 as distance ';			
		}			
		
		$where = 'where product.status = "'.$status.'"';
		
		if($categoryId !='' && $categoryId !='0'){
			$where .= " and product.category_id = '".$categoryId."'" ;
		}
		if($subCategoryId !='' && $subCategoryId !='0'){
			$where .= " and product.subcategory_id = '".$subCategoryId."'" ;
		}
		if($all){
			$subQuery = 'SELECT product_id as pId from wishlist where user_id="'.$userId.'" ';
			$favResult = $this->_db->my_query_result($subQuery);
			$favourite= array();
			foreach ($favResult as $res){
				$favourite[] = $res['pId'];
				
			}
		}else if($userId !=''){
			$where .= " and product.owner_id = '".$userId."'" ;
		}
		if($productType !=''){
			$where .= " and product.product_type = '".$productType."'" ;
		}
		if($price !=''){
		$where .= " and product.price = '".$price."'" ;
		}
		if($countryId !=''){
		$where .= " and product.country_id = '".$countryId."'" ;
		}
		if($stateId !=''){
		$where .= " and product.state_id = '".$stateId."'" ;
		}
		if($cityId !=''){
		$where .= " and product.city_id = '".$cityId."'" ;
		}
		if($title !=''){
			$where .= " and product.product_name like '%".$title."%'" ;
		}
		$query = "SELECT product.* ".$selectQ." , users.first_name as owner_name,categories.category_name,subcategory.subcategory_name FROM product INNER JOIN users on users.id = product.owner_id INNER JOIN categories on categories.id = product.category_id INNER JOIN subcategory on subcategory.id = product.subcategory_id ".$where.' AND product.is_delete = 0 '.$selectH;
		
		/*get code count*/
		//$count = "SELECT COUNT(product.id) as total FROM product ".$where.' AND product.is_delete = 0';
		$countR=$this->_db->my_query_result($query);
		$countResult = array();
		$countResult['total'] =count($countR); 
		
		$query .='ORDER BY product.id DESC LIMIT '.$offset.',10';
		
		$result = $this->_db->my_query_result($query);
		foreach ($result as $key=>$res){
				$result[$key]['owner_name']= ucfirst($res['owner_name']);
				$fav = in_array($res['id'],$favourite);
				$result[$key]['fav']= ($fav?1:0);
				$result[$key]['product_name']= ucfirst($res['product_name']);
				$result[$key]['category_name']= ucfirst($res['category_name']);
				$result[$key]['subcategory_name']= ucfirst($res['subcategory_name']);
			if($res['product_type'] == 1){
				$result[$key]['product_type']= "Sell";
			}else{
				$result[$key]['product_type']= "Rent";	
			}
			if($res['status'] == 1){
				$result[$key]['status']= "Activated";
			}else{
				$result[$key]['status']= "Deactivated";	
			}
				$result[$key]['features']= ucfirst($res['features']);
				$result[$key]['product_description']= ucfirst($res['product_description']);
				$result[$key]['created_date']= date("d M Y", strtotime($res['created_date']));
				$result[$key]['country_name'] = $this->getCountryNameById($res['country_id']);
				$result[$key]['state_name'] = $this->getStateNameById($res['state_id']);
				$result[$key]['city_name'] = $this->getCityNameById($res['city_id']);
				if($res['product_image']!=''){
					$res['product_image']=product_FOLDER_PATH.$res['product_image'];
					$result[$key]['images']=$this->getProductImagesId($res['id'],$res['product_image']);
				}
				$result[$key]['product_image']=$res['product_image'];
				
			}
			
			if(!empty($result)){
			$records_array['status'] = "1";
			$records_array['record'] = $result;
			$records_array['total'] = $countResult['total'];
			$records_array['locale'] = $locale;
            $records_array['msg'] = $this->_common->langText($locale, 'list.get.sucess');
			
			}else{
				$records_array['status']    = "0";
				$records_array['locale'] = $locale;
				$records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
			}
			
        return $records_array;
    }
    /**
     * @method : getProductDetailById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
	 
    public function getProductDetailById() 
    {	
        $productId = (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
		$result='';
        $locale  = $this->_common->locale();
		if(!empty($productId)){
			$query = "SELECT product.*,users.first_name as owner_name,categories.category_name, subcategory.subcategory_name  FROM product INNER JOIN users on users.id = product.owner_id INNER JOIN categories on categories.id = product.category_id INNER JOIN subcategory on subcategory.id = product.subcategory_id  WHERE product.id='".$productId."'";
			$result = $this->_db->my_query_result($query);
			foreach ($result as $key=>$res){
				//print_r($res);die;
				$result[$key]['owner_name']= ucfirst($res['owner_name']);
				$result[$key]['product_name']= ucfirst($res['product_name']);
				$result[$key]['features']= ucfirst($res['features']);
				$result[$key]['category_name']= ucfirst($res['category_name']);
				$result[$key]['subcategory_name']= ucfirst($res['subcategory_name']);
			if($res['product_type'] == 1){
				$result[$key]['product_type']= "Sell";
			}else{
				$result[$key]['product_type']= "Rent";	
			}
			if($res['status'] == 1){
				$result[$key]['status']= "Activated";
			}else{
				$result[$key]['status']= "Deactivated";	
			}
				$result[$key]['product_description']= ucfirst($res['product_description']);
				$result[$key]['created_date']= date("d M Y", strtotime($res['created_date']));
				$result[$key]['product_image']=product_FOLDER_PATH.$res['product_image'];
				$result[$key]['country_name'] = $this->getCountryNameById($res['country_id']);
				$result[$key]['state_name'] = $this->getStateNameById($res['state_id']);
				$result[$key]['city_name'] = $this->getCityNameById($res['city_id']);
				$result[$key]['images']=$this->getProductImagesId($res['id'],product_FOLDER_PATH.$res['product_image']);
			}
			
			if(!empty($result)){
			$records_array['status']    = "1";
			$records_array['record'] = $result;
            $records_array['msg'] = $this->_common->langText($locale, 'listdetail.get.sucess');
			
			}else{
				$records_array['status']    = "0";
				$records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
			}
		}else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
		}	
        return $records_array;
    }
	
	 /**
     * @method : getWishlist
     * @param :  userId
     * @return : array
     */
    public function getWishlist() 
    {	
		$userId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$result='';
        $locale  = $this->_common->locale();
		$query = "SELECT product.*,users.first_name as owner_name,wishlist.id AS wishlistID  FROM product 
		INNER JOIN wishlist ON wishlist.product_id = product.id 
		INNER JOIN users ON users.id = product.owner_id 
		WHERE wishlist.user_id = '".$userId."' ORDER BY wishlistID DESC" ; 
		$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				foreach ($result as $key=>$res){
					$result[$key]['owner_name']= ucfirst($res['owner_name']);
					$result[$key]['product_name']= ucfirst($res['product_name']);
					$result[$key]['features']= ucfirst($res['features']);
					$result[$key]['product_description']= ucfirst($res['product_description']);
				if($res['product_type'] == 1){
					$result[$key]['product_type']= "Sell";
				}else{
					$result[$key]['product_type']= "Rent";	
				}
				if($res['status'] == 1){
					$result[$key]['status']= "Activated";
				}else{
					$result[$key]['status']= "Deactivated";	
				}
					$result[$key]['product_image']=product_FOLDER_PATH.$res['product_image'];
					$result[$key]['created_date']= date("d M Y", strtotime($res['created_date']));
					$result[$key]['category_name']= $this->getCategoryNameById($res['category_id']);
					$result[$key]['subcategory_name']= $this->getSubCategoryNameById($res['subcategory_id']);
					$result[$key]['country_name'] = $this->getCountryNameById($res['country_id']);
					$result[$key]['state_name'] = $this->getStateNameById($res['state_id']);
					$result[$key]['city_name'] = $this->getCityNameById($res['city_id']);
				}
				
				$records_array['status'] = "1";
                $records_array['data'] = $result;
				$records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'get_wishlist_success');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'list.get.error');
            }
        
        return $records_array;
    }
	
	
	/**
     * @method : addProductInWishlist
     * @param :  userId
     * @param :  productId
     * @return : array
     */
    public function addProductInWishlist() 
    {	
		$userId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$productId = (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
		$result='';
        $locale  = $this->_common->locale();
		if($userId !='' && $productId !=''){
			$query = "SELECT id  FROM wishlist	WHERE user_id = '".$userId."' AND product_id = '".$productId."'"; 
			$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
				$records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'wishlist.exis.sucess');
			}else{
				$query = "INSERT INTO wishlist SET `user_id` = '".$userId."', `product_id` = '".$productId."'";
				$result = $this->_db->my_query_result($query);
                $records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'wishlist.add.sucess');
            }
        }else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
			
		}
        return $records_array;
    }
	
	/**
     * @method : removeProductInWishlist
     * @param :  userId
     * @param :  productId
     * @return : array
     */
    public function removeProductInWishlist() 
    {	
		$userId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$productId = (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
		$result='';
        $locale  = $this->_common->locale();
		if($userId !='' && $productId !=''){
			$query = "DELETE  FROM wishlist	WHERE user_id = '".$userId."' AND product_id = '".$productId."'"; 
			$result = $this->_db->my_query_result($query);	
			$records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'wishlist.delete.sucess');
		}else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
			
		}
        return $records_array;
    }
	/**
     * @method : addEnquiry
	 * @param :  productId
     * @return : array
     */
    public function addEnquiry() 
    {	
		$productId    = (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
		$userId    = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'0');
		$name         = (isset($_REQUEST['name'])?$_REQUEST['name']:'');
		$email        = (isset($_REQUEST['email'])?$_REQUEST['email']:'');
		$contact      = (isset($_REQUEST['contact'])?$_REQUEST['contact']:'');
		$description  = (isset($_REQUEST['description'])?$_REQUEST['description']:'');
		$result='';
        $locale  = $this->_common->locale();
		if($productId !='' && $name !='' && $email !='' && $contact !=''){
				$query = "INSERT INTO enquiry SET `name` = '".$name."',`user_id`='".$userId."', `product_id` = '".$productId."', `email` = '".$email."', `contact` = '".$contact."', `description` = '".$description."'";
				$result = $this->_db->my_query_result($query);
                $records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'enquiry.add.sucess');
            
        }else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
			
		}
        return $records_array;
    }
	/**
     * @method : getCountryNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getCountryNameById($id="") 
    {
        if (!empty($id)) {
			$query = "SELECT country_name FROM country WHERE country_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysqli_set_charset("UTF8", $res);
            $name=$res[0]['country_name'];
		}	
		return $name;
    }
	/**
     * @method : getStateNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
     public function getStateNameById($id="") 
    {
         if (!empty($id)) {
			$query = "SELECT state_name FROM state WHERE state_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['state_name'];
		}	
        return $name;
    }
	/**
     * @method : getCityNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
   public function getCityNameById($id="") 
    {
        if (!empty($id)) {
			$query = "SELECT city_name FROM city WHERE city_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['city_name'];
		}	
        return $name;
    }
	/**
     * @method : getProductImagesId
     * @param :  product_id
     * @param :  userId
     * @return : array
     */
    public function getProductImagesId($id="",$mainImage='') 
    {
		$records_array[]['image_url']=$mainImage;
        if (!empty($id)) {
			$query = "SELECT image_url FROM product_image  WHERE product_id='".$id."'"; 
            $result = $this->_db->my_query_result($query);
			foreach ($result as $key=>$res){
				//$result[$key]['image_url']=product_FOLDER_PATH.$res['image_url'];
				$records_array[]['image_url']=product_FOLDER_PATH.$res['image_url'];
			}
			//$records_array=array();
			/*if(empty($result)){
				$query = "SELECT * FROM product  WHERE id='".$id."'"; 
				$result1 = $this->_db->my_query_result($query);
				$result[0]['image_url'] = product_FOLDER_PATH.$result1[0]['product_image'];
			}*/
            //$records_array = $result;			
		}
		return $records_array;
    }
	
	/**
     * @method : getCategoryNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getCategoryNameById($id="") 
    {
       if (!empty($id)) {
			$query = "SELECT category_name FROM categories WHERE id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
           $name=$res[0]['category_name'];
		}	
        return $name;
    }
	
	/**
     * @method : getSubCategoryNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getSubCategoryNameById($id="") 
    {
       if (!empty($id)) {
			$query = "SELECT subcategory_name FROM subcategory WHERE id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
           $name=$res[0]['subcategory_name'];
		}	
        return $name;
    }
	/**
     * @method : deleteJobById
     * @param :  userId,jobId
     * @return : array
     */
    public function deleteProductById() 
    {
		$userId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$productId = (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
        $locale  = $this->_common->locale();
        if (!empty($productId && $userId)) {
			$query = "UPDATE product SET `status`= 0 ,`is_delete`=1 WHERE `id`='".$productId."' AND `owner_id`='".$userId."'";
			$res = $this->_db->my_query($query);
		if($res){
		   $records_array['status'] = "1";
		   $records_array['msg'] = $this->_common->langText($locale, 'product.delete.sucess');
		   }else{
			$records_array['status'] = "0";
		   $records_array['msg'] = $this->_common->langText($locale, 'product.delete.error');
		   }
		}	
        return $records_array;
    }
	/**
     * @method : addProduct
     * @param :  userId
     * @return : array
     */
	public function addProduct(){
		$userId 		= (isset($_REQUEST['userId'])?$_REQUEST['userId']:'');
		$productId 		= (isset($_REQUEST['productId'])?$_REQUEST['productId']:'');
		$categoryId 	= (isset($_REQUEST['categoryId'])?$_REQUEST['categoryId']:'');
		$subCategoryId 	= (isset($_REQUEST['subCategoryId'])?$_REQUEST['subCategoryId']:'');
		$productType 	= (isset($_REQUEST['productType'])?$_REQUEST['productType']:'');
		$name 			= (isset($_REQUEST['name'])?$_REQUEST['name']:'');
		$description	= (isset($_REQUEST['description'])?$_REQUEST['description']:'');
		$price 			= (isset($_REQUEST['price'])?$_REQUEST['price']:'');
		$currency 		= (isset($_REQUEST['currency'])?$_REQUEST['currency']:'');
		$features 		= (isset($_REQUEST['features'])?$_REQUEST['features']:'');
		$countryId 		= (isset($_REQUEST['countryId'])?$_REQUEST['countryId']:'');
		$stateId 		= (isset($_REQUEST['stateId'])?$_REQUEST['stateId']:'');
		$cityId 		= (isset($_REQUEST['cityId'])?$_REQUEST['cityId']:'');
		$lat 			= (isset($_REQUEST['lat'])?$_REQUEST['lat']:'');
		$long			= (isset($_REQUEST['long'])?$_REQUEST['long']:'');
		$address 		= (isset($_REQUEST['address'])?$_REQUEST['address']:'');
		$status 		= (isset($_REQUEST['status'])?$_REQUEST['status']:1);
		$image 			= (isset($_REQUEST['image'])?$_REQUEST['image']:'');
		$locale  = $this->_common->locale();
		if (($userId !='') &&  ($productId =='')) {
			if(!empty($image)){
				$folder = PRODUCT_UPLOAD_PATH;
				$imgByteArr = $_REQUEST['image'];      
				$image_url= $this->imageUpload($imgByteArr,$folder);
			}
			
			$query = "Insert into product SET `owner_id`='" . $userId . "',	`category_id`='" . $categoryId . "',`subcategory_id`='" . $subCategoryId . "', `product_type`='" . $productType . "',`product_name`='" . $name . "',`product_description`='" . $description . "',`price`='" . $price . "',`currency`='" . $currency . "',	`features`='" . $features . "',	`country_id`='" . $countryId . "',	`state_id`='" . $stateId . "',`city_id`='" . $cityId . "',`lat`='" . $lat . "',	`long`='" . $long . "',
				`address`='" . $address . "',`product_image`='" . $image_url . "',`status`='" . $status . "',`created_date` = '".CURRENT_TIME."'";
				
			$insert   = $this->_db->my_query($query);			
            if(!empty($insert)){
				$records_array['msg'] = $this->_common->langText($locale, 'product.add.success');
				$records_array['status'] = "1";
			}else{
				$records_array['status'] = "0";
				$records_array['msg']    = $this->_common->langText($locale, 'product.add.error');
			}
		}else if(($userId !='') &&  ($productId !='')){
			$parameter = '';
			if($status !=''){
				$parameter .= " status = '".$status."'" ;
				$parameter .= " ,modified_date = '".CURRENT_TIME."'" ;
			}
			if($categoryId !=''){
				$parameter .= " ,category_id = '".$categoryId."'" ;
			}
			if($subCategoryId !=''){
				$parameter .= " ,subcategory_id = '".$subCategoryId."'" ;
			}
			if($productType !=''){
				$parameter .= " ,product_type = '".$productType."'" ;
			}
			if($name !=''){
				$parameter .= " ,product_name = '".$name."'" ;
			}
			if($description !=''){
				$parameter .= " ,product_description = '".$description."'" ;
			}
			if($price !=''){
				$parameter .= " ,price = '".$price."'" ;
			}
			if($currency !=''){
				$parameter .= " ,currency = '".$currency."'" ;
			}
			if($features !=''){
				$parameter .= " ,features = '".$features."'" ;
			}
			if($countryId !=''){
				$parameter .= " ,country_id = '".$countryId."'" ;
			}
			if($stateId !=''){
				$parameter .= " ,state_id = '".$stateId."'" ;
			}
			if($cityId !=''){
				$parameter .= " ,city_id = '".$cityId."'" ;
			}
			if($lat !=''){
				$parameter .= " ,lat = '".$lat."'" ;
			}
			if($long !=''){
				$parameter .= " ,`long` = '".$long."'" ;
			}
			if($address !=''){
				$parameter .= " ,address = '".$address."'" ;
			}
			if(!empty($image)){
				$folder = PRODUCT_UPLOAD_PATH;
				$imgByteArr = $_REQUEST['image'];      
				$image_url= $this->imageUpload($imgByteArr,$folder);
				$parameter .= " ,product_image = '".$image_url."'" ;
			}
				$where = ' where id = "'.$productId.'"';
				$sql_get_user = 'UPDATE product SET '.$parameter.$where; 
				$update   = $this->_db->my_query($sql_get_user);
				if($update){
					$records_array['msg'] = $this->_common->langText($locale, 'product.updated.successful');
					$records_array['status'] = "1";
				}else{
					$records_array['status'] = "0";
					$records_array['msg']    = $this->_common->langText($locale, 'product.updated.error');
				}
		}else{
				$records_array['status'] = "0";
				$records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
		}	
        return $records_array;
	}
	
	
	/**
    * @This function use for imageupload
    * @Input: 
    * @output: return message and status
    * @access public
    */  
    public function imageUpload($encoded_image=null,$upload_path) {
		$decoded_image = base64_decode($encoded_image);
		$f = finfo_open();
        $mime_type = finfo_buffer($f, $decoded_image, FILEINFO_MIME_TYPE);
		$file_type = explode('/', $mime_type);
        if(!empty($file_type[1])){
            $ext = $file_type[1];
        }else{
            $ext = 'png';
        }
        
        $imgname       = md5(uniqid()) . '.'.$ext;
        $ret =  file_put_contents($upload_path."". $imgname, $decoded_image);
        $actual       = $upload_path ."" .$imgname; // Set the actual image name
        
		return $imgname;
    }
}
?>
