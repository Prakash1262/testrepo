<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class commonclass {
    
    /* IMAGE URL CONSTANT	
     * @method __construct
     * @see private constructor to protect beign inherited
     * @access private
     * @return void
     */
    
    public function __construct() {
        /// -- Create Database Connection instance --
        $this->_db      = env::getInst();
        $records_array  = array();
        $records_array1 = array();
    }
    
    /**
     * @method : userInactivated : This function is for return the data for user Inactivated by admin.
     * @return : User has been deactivated by admin so he can not perfomr any action right now.
     */
    public function userInactivated() {
        $regis_locale            = $this->locale();
        $records_array['status'] = "1000";
        $records_array['locale'] = $regis_locale;
        $records_array['msg']    = $this->langText($regis_locale, 'txt.website.user.inactivated');
        return $records_array;
    }
    /* userInactivated from mobile end */
    /** 
     * @method : getThumbImgByteCode : Get thumb image url.
     * @param = imgName
     * @return = Code for return image url.
     */
    public function getThumbImgByteCode($imgName) {
        $byteCode = "";
        if ($imgName != "no_img.png") {
            $byteCode = IMG_URL . $imgName;
        }
        return $byteCode;
    }
    
    /** 
     * @method : getFullImgByteCode : Get large image url.
     * @param = imgName
     * @return = Code for return image url.
     */
    public function getFullImgByteCode($imgName) {
        $byteCode = "";
        if ($imgName != "no_img.png") {
            $byteCode = IMG_URL . $imgName;
        }
        return $byteCode;
    }
    
    /** 
     * @method : langText : function for load the language files and fetch the text content
     * @$locale = language name.
     * @string = Key of the language text.
     */
    public function langText($locale, $string) {
        header('Content-Type: text/html; charset=utf-8');
        /// --- Load Languge file ---
        if ($locale == 'de')
            $lang = load_lang($locale, "german");
        else
            $lang = load_lang($locale, "english");
        /// --- Convert Key to Language ---
        return $lang["$string"];
    }
    
    /** 
     * @method : locale : function for load the language type en or de
     * @$locale = language name.
     * @string = Key of the language type.
     */
    public function locale() {
        
        if (!empty($_REQUEST['locale']) && $_REQUEST['locale'] == 'de')
            $locale = $_REQUEST['locale'];
        else
            $locale = 'en';
        
        return $locale;
    }
	
	    /**
     * @method : mediaUpload
     * @param : $userId, $imgurl (base64 encoded data)
     * @return : This function will upload image. void return.
     */
    function mediaUpload($imgurl,$type=0) {
        $userId        = $userid;
        $encoded_image = $imgurl;
        
        $upload_path      = IMG_FOLDER_PATH;
		
        $LoginUserDetails = $this->getUserDetails($userId);
        if ($LoginUserDetails->userImage != "") {
            $dbimgname = $LoginUserDetails->userImage;
            unlink($upload_path . '/' . $dbimgname);
            unlink($upload_path . '/thumb_img/' . $dbimgname);
        }
        $decoded_image = base64_decode($encoded_image);
		if($type==0){
			$imgname       = md5(uniqid()) . ".jpg";
		}else{
			$imgname       = md5(uniqid()) . ".mp4";
		}
        file_put_contents($upload_path . "/" . $imgname, $decoded_image);
        
        $thumbnail    = $upload_path . "/thumb_img/" . $imgname; // Set the thumbnail name
        $actual       = $upload_path . "/" . $imgname; // Set the actual image name
        // Get new sizes
        $upload_image = $upload_path . "/" . $imgname;
        list($width, $height) = getimagesize($upload_image);
        $newwidth  = 196; // This can be a set value or a percentage of original size ($width)
        $newheight = 196; // This can be a set value or a percentage of original size ($height)
        // Load the images
        $thumb     = imagecreatetruecolor($newwidth, $newheight);
        $source    = imagecreatefromjpeg($upload_image);
        
        imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height); // Resize the $thumb image.
        imagejpeg($thumb, $thumbnail, 75); // Save the new file to the location specified by $thumbnail
        
        return $imgname;
    }
    /**
     * @method : imageUpload
     * @param : $userId, $imgurl (base64 encoded data)
     * @return : This function will upload image. void return.
     */
    function imageUpload($userid, $imgurl) {
        $userId        = $userid;
        $encoded_image = $imgurl;
        
        $upload_path      = dirname(__FILE__)."/../uploads/";
		
        $LoginUserDetails = $this->getUserDetails($userId);
        if ($LoginUserDetails->userImage != "") {
            $dbimgname = $LoginUserDetails->userImage;
            unlink($upload_path . '/' . $dbimgname);
            unlink($upload_path . '/thumb_img/' . $dbimgname);
        }
        $decoded_image = base64_decode($encoded_image);
        $imgname       = md5(uniqid()) . ".jpg";
        file_put_contents($upload_path . "/" . $imgname, $decoded_image);
        
        $thumbnail    = $upload_path . "/thumb_img/" . $imgname; // Set the thumbnail name
        $actual       = $upload_path . "/" . $imgname; // Set the actual image name
        // Get new sizes
        $upload_image = $upload_path . "/" . $imgname;
        list($width, $height) = getimagesize($upload_image);
        $newwidth  = 196; // This can be a set value or a percentage of original size ($width)
        $newheight = 196; // This can be a set value or a percentage of original size ($height)
        // Load the images
        $thumb     = imagecreatetruecolor($newwidth, $newheight);
        $source    = imagecreatefromjpeg($upload_image);
        
        imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height); // Resize the $thumb image.
        imagejpeg($thumb, $thumbnail, 75); // Save the new file to the location specified by $thumbnail
        
        return $imgname;
    }
    
    /**
     * @method : getUserDetails. This function will check user register or not.
     * @param : userId
     * @return : This function give user details by userId - return user_data 
     */
    public function getUserDetails($userId) {
        $this->_db->my_query("SET NAMES 'UTF8'");
        $UserDetailSql    = "SELECT * FROM `users` WHERE id='" . $userId . "'";
        $UserDetailSqlVal = $this->_db->my_query($UserDetailSql);
        //mysql_set_charset("UTF8", $UserDetailSqlVal);
        $UserDetailResult = $this->_db->my_fetch_object($UserDetailSqlVal);
        return $UserDetailResult;
    }
    
    /**
     * @method : getUserDetailsByEmailId. This function will check user register or not.
     * @param : email
     * @return : This function give user details by email id - return user_data 
     */
    public function getUserDetailsByEmailId($email) {
	
        $this->_db->my_query("SET NAMES 'UTF8'");
        $UserDetailSql    = "SELECT * FROM `users` WHERE email='" . $email . "'";
        $UserDetailSqlVal = $this->_db->my_query($UserDetailSql);
        //mysql_set_charset("UTF8", $UserDetailSqlVal);
        $UserDetailResult = $this->_db->my_fetch_object($UserDetailSqlVal);
		
        return $UserDetailResult;
    }
	
	
	 public function getUserDetailsBysocialId($socialId) {
	
        $this->_db->my_query("SET NAMES 'UTF8'");
        $UserDetailSql    = "SELECT * FROM `users` WHERE socialId='" . $socialId . "'";
		$UserDetailSqlVal = $this->_db->my_query($UserDetailSql);
        //mysql_set_charset("UTF8", $UserDetailSqlVal);
        $UserDetailResult = $this->_db->my_fetch_object($UserDetailSqlVal);
		
        return $UserDetailResult;
    }
   
    /**
     * @method : generateRandomString = to generate rand string.
     * @param : string length optional.
     * @return : string
     */
     function generateRandomString($length = 4) {
		$characters = '0123456789@!ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
	
	
	
/** 
* Function for add Video File - Start
* return video file
**/ 
	public function uploadPostVideoFile($videoData)
	{  
		$extension = ".mp4";
		$upload_path = dirname(__FILE__)."/../media_post/";
	       
		$randomNumber = time().rand();
		$thumbImgName = $randomNumber.".jpg";
		$videoName = $randomNumber.$extension;
		$fullPath = $videoName;
		
		file_put_contents($upload_path.$fullPath,base64_decode($videoData));       
		return  $videoName;
	}	


	function uploadPostImageBlob($encoded_image)
	{ 
		//=========upload image tr================
		/*$target = IMG_FOLDER_PATH.'/media_post/'; //set image upload path
		$imgName  = md5(uniqid()) . ".jpg"; 
		 $target = $target .$imgName;
		 if(move_uploaded_file($encoded_image, $target)) 
		 {
		 //echo "The file ". basename( $_FILES['file']['name']). " has been uploaded";
		 } 
		 else {
		// echo "Sorry, there was a problem uploading your file.";
		 }*/
		 //---------------------------------------------------------------------
		 
			$path = IMG_FOLDER_PATH.'/media_post/'; //set image upload path

			$img = $encoded_image;
			$imgName = md5(uniqid());
			$dst = $path .$imgName;

			if (($img_info = getimagesize($img)) === FALSE)
			die("Image not found or not an image");

			$width = $img_info[0];
			$height = $img_info[1];
			$extN = '';

			switch ($img_info[2]) {
			case IMAGETYPE_GIF  : $src = imagecreatefromgif($img); $extN='.gif';  break;
			case IMAGETYPE_JPEG : $src = imagecreatefromjpeg($img); $extN='.jpg'; break;
			case IMAGETYPE_PNG  : $src = imagecreatefrompng($img);  $extN='.png'; break;
			default : die("Unknown filetype");
			}

			$tmp = imagecreatetruecolor($width, $height);
			imagecopyresampled($tmp, $src, 0, 0, 0, 0, $width, $height, $width, $height);
			imagejpeg($tmp, $dst.".jpg");
		 //---------------------------------------------------------------------
		 
		//============upload image tr=============

		/*$upload_path   = IMG_FOLDER_PATH.'/media_post/'; //set image upload path
		$decoded_image = base64_decode($encoded_image);
        $imgName     = md5(uniqid()) . ".jpg";
        file_put_contents($upload_path . "/" . $imgName, $decoded_image);*/
		
		return $imgName.$extN ;
		
	
	}
	
}
?>
