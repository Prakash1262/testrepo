<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class users {
    
    public function __construct() {
        /// -- Create Database Connection instance --
        $this->_db      = env::getInst();
        $this->_common  = new commonclass(); /// -- Create get laguage instance --
        
    }
    /**
    * @This function use for user_info_by_email
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function user_info_by_email($email){
		$email = $email;
		$error = 'error';
		$query = "SELECT * FROM `users` where email = '".$email."' ";
		$result = $this->_db->my_query($query,$error);
		$count = mysql_num_rows($result);
		return $count;
	} 
	
	public function test() {
		echo '>>>>>> test '; print_r($_REQUEST['email']); die;
		$email = $_REQUEST['email'];

		print_r($_REQUEST); 

	}
	 /**
    * @This function use for user registration
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function signup() {
		
		$email 		     = trim($_REQUEST['email']);
        //$contact 	     = trim($_REQUEST['contact']);             
        $name 		     = trim($_REQUEST['name']);
		//$username 		     = trim($_REQUEST['username']);
        $deviceType      = $_REQUEST['deviceType']; 
		$deviceToken = (isset($_REQUEST['deviceToken'])?$_REQUEST['deviceToken']:'');
        //$lat             = (isset($_REQUEST['lat'])?$_REQUEST['lat']:'');
		//$long            = (isset($_REQUEST['long'])?$_REQUEST['long']:'');
        $password        = md5($_REQUEST['password']);     
        //$image_url       = (isset($_REQUEST['image_url'])?$_REQUEST['image_url']:'');
		$locale = $this->_common->locale();
		if (!empty($email) && !empty($password) && !empty($deviceType)) {
			$email_exsits = $this->user_info_by_email(trim($email));
			//print_r($email_exsits); die;
		 if (!empty($email_exsits)) {
			  $records_array['status'] = "0";
              $records_array['locale'] = $locale;
			  $records_array['msg']    = $this->_common->langText($locale, 'txt.registration.same.email.address');
		 
		return $records_array;
	 
	 }		if(!empty($image_url)){
				$folder = USER_UPLOAD_PATH;
				$imgByteArr = $_REQUEST['image_url'];      
				$image_url= $this->imageUpload($imgByteArr,$folder);
			}
			$activation_code = sha1(time()) . mt_rand();
       			
            $sql  = " INSERT INTO users SET ";
            $sql .= " email='".$email."' , ";  
            //$sql .= " username='".$username."' , ";  
            //$sql .= " mobile_phone='".$contact."' , ";
            $sql .= " fname='".$name."' , ";
            $sql .= " deviceType='".$deviceType."',";
            $sql .= " deviceToken='".$deviceToken."',";
            $sql .= " password='".$password."',";
            //$sql .= " lat='".$lat."',";
            //$sql .= " `long`='".$long."',";
            $sql .= " created_at='".CURRENT_TIME."',";
            //$sql .= " profile_image ='".$image_url ."',";
            $sql .= " varification_code ='".$activation_code ."',";
            $sql .= " status = 1";
            //echo $sql; die;
				$this->_db->my_query($sql);
				$userId = $this->_db->my_query_id();
			    /*$emailData['first_name'] = ucfirst($name);
				$emailData['recieverId'] = $email;
				$emailData['subject'] = 'Rigbuy: Registration';
				$emailData['template'] = 'email';
				$emailData['url'] = BASE_URL."user/verify_email/".$activation_code;				
				$emailData['code'] = $activation_code;
				$emailData['id']=8;//template id 8 Rigbuy: Registration
				
				$getEmailData = "SELECT * FROM `email_template` where `id`=8";
				$getEmailData     = $this->_db->my_query_result($getEmailData);
				
				$search    = array("{#FIRSTNAME#}", "{#LINKTOPATH#}");
				$replace   = array($emailData['first_name'], $emailData['url']);
				$emailBody=  str_replace($search, $replace, $getEmailData[0]['body']);
		
				$header = "MIME-Version: 1.0\r\n";
				$header .= "Content-type: text/html\r\n";
				$retval = mail($email,$emailData['subject'],$emailBody,$header); */
				
				
            if ($userId) {
				$userinfo = $this->getUserInfo($userId);
                $response['id'] = $userId;
				$response['records'] = $userinfo;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "Registration successful."; //, Please check your emailbox for verification email/link.
                
            }
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
    /**
     * @method : login => For user login.
     * @param :  user_email
     * @param :  password
     * @return : array
     */
    public function login() 
    {	 
        $email   	 = (isset($_REQUEST['email'])?$_REQUEST['email']:'');
        $password 	 = (isset($_REQUEST['password'])?$_REQUEST['password']:'');
		$socialId    = (isset($_REQUEST['socialId'])?$_REQUEST['socialId']:'');
		$deviceType  = (isset($_REQUEST['deviceType'])?$_REQUEST['deviceType']:'');
		$deviceToken = (isset($_REQUEST['deviceToken'])?$_REQUEST['deviceToken']:'');
		//$name        = (isset($_REQUEST['name'])?$_REQUEST['name']:'');
		//$lat         = (isset($_REQUEST['lat'])?$_REQUEST['lat']:'');
		//$long        = (isset($_REQUEST['long'])?$_REQUEST['long']:'');
		//$image_url   = (isset($_REQUEST['image_url'])?$_REQUEST['image_url']:'');
		
      
        $locale  = $this->_common->locale();
        if (!empty($email) && !empty($password)) {
		
			$query = "SELECT COUNT(id) as user_count,status,is_deleted FROM users WHERE email = '".$email."' 
                AND password = '".md5($password)."'";
            $res = $this->_db->my_query($query);
			$sql_get_user = "UPDATE users SET `deviceToken`='" .$deviceToken. "',`last_logged_in` = '".CURRENT_TIME."' WHERE `email`= '".$email."'"; //,`lat`='".$lat."',`long`='".$long."'
			$update   = $this->_db->my_query($sql_get_user);
			$userId = $this->getUserIdByEmailId($email);
			$result = $this->_db->my_fetch_object($res);
			//echo "<pre>";print_r($result);die;
			$userinfo = $this->getUserInfo($userId);
			//$userSocialLink = $this->getUserSocialLink($userId);
			if($result->user_count>0 && $result->status == 1){
				$records_array['records'] =$userinfo;
                $records_array['status'] = "1";
                $records_array['locale'] = $locale;
				//$records_array['social_link'] = $userSocialLink;
				$records_array['userId'] = $userId;
                $records_array['msg']    = $this->_common->langText($locale, 'login_success');
            }else if($result->user_count>0 && $result->status == 0 && $result->is_deleted == 1){
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
				$records_array['userId'] = $userId;
                $records_array['msg']    = $this->_common->langText($locale, 'account_status');
            }else if($result->user_count>0 && $result->status == 0 && $result->is_deleted == 0){
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
				$records_array['userId'] = $userId;
                $records_array['msg']    = $this->_common->langText($locale, 'account_verify');
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = $this->_common->langText($locale, 'login_error');
            }
        }else if(!empty($socialId))
		{
			$checkUserExist = $this->checksocialIdExist($socialId);
			
			if($checkUserExist == 1){
					$sql_get_user = "UPDATE users SET `deviceToken`='" .$deviceToken. "',`last_logged_in` = '".CURRENT_TIME."' WHERE `socialId`= '".$socialId."'"; //,`lat`='".$lat."',`long`='".$long."'
						$update   = $this->_db->my_query($sql_get_user);
						$userId = $this->getUserIdBysocialId($socialId);
						$userinfo = $this->getUserInfo($userId);
						$records_array['status'] = "1";
						$records_array['locale'] = $locale;
						$records_array['records'] =$userinfo;
						$records_array['social_link'] = $userSocialLink;
						$records_array['userId'] = $userId;
						$records_array['msg']    = $this->_common->langText($locale, 'login_success');
			
					}else if($checkUserExist == 2){
						$records_array['status'] = "0";
						$records_array['locale'] = $locale;
						$records_array['userId'] = "";
						$records_array['msg']    = $this->_common->langText($locale, 'account_status');
			
					}else{
						$checkEmailExist = $this->user_info_by_email($email);
						if($checkEmailExist > 0){
							$sql_get_user = "UPDATE users SET `deviceToken`='" .$deviceToken. "',`last_logged_in` = '".CURRENT_TIME."',`lat`='".$lat."',`long`='".$long."',`socialId`= '".$socialId."' WHERE `email`= '".$email."'";
							$update   = $this->_db->my_query($sql_get_user);
							$userId = $this->getUserIdBysocialId($socialId);
							$userinfo = $this->getUserInfo($userId);
							$records_array['status'] = "1";
							$records_array['locale'] = $locale;
							$records_array['records'] =$userinfo;
							$records_array['social_link'] = $userSocialLink;
							$records_array['userId'] = $userId;
							$records_array['msg']    = $this->_common->langText($locale, 'login_success');
						}else{
							$sql_get_user = "INSERT INTO users SET `socialId`='" . $socialId . "',`deviceToken`='" .$deviceToken. "',`deviceType`='" .$deviceType. "',`created_at` = '".CURRENT_TIME."',`status`=1,`lat`='".$lat."',`long`='".$long."',`first_name`='".$name."',`username`='".$email."',`email`='".$email."',`profile_image`='".$image_url."'";
							$insert   = $this->_db->my_query($sql_get_user);
							$userId = $this->getUserIdBysocialId($socialId);
							$userinfo = $this->getUserInfo($userId);
							$records_array['status'] = "1";
							$records_array['locale'] = $locale;
							$records_array['records'] =$userinfo;
							$records_array['social_link'] = $userSocialLink;
							$records_array['userId'] = $userId;
							$records_array['msg']    = $this->_common->langText($locale, 'login_success');
						}
					}
		
		}else {
            $records_array['status'] = "0";
            $records_array['locale'] = $locale;
			$response['social_link'] = [];
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.fill.all.required.fields');
        }
        return $records_array;
    }
    public function getCountryNameById($id="") 
    {
        
        if (!empty($id)) {
			$query = "SELECT country_name FROM country WHERE country_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysqli_set_charset("UTF8", $res);
            $name=$res[0]['country_name'];
		}	
		
        return $name;
    }
	/**
     * @method : getStateNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getStateNameById($id="") 
    {
         if (!empty($id)) {
			$query = "SELECT state_name FROM state WHERE state_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['state_name'];
		}	
        return $name;
    }
	/**
     * @method : getCityNameById
     * @param :  company_id
     * @param :  userId
     * @return : array
     */
    public function getCityNameById($id="") 
    {
        if (!empty($id)) {
			$query = "SELECT city_name FROM city WHERE city_id='".$id."'"; 
            $res = $this->_db->my_query_result($query);
            //mysql_set_charset("UTF8", $res);
            $name=$res[0]['city_name'];
		}	
        return $name;
    }
	
	function getUserInfo($userId="") {
        $loginUserId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:''); // mandatary parameter.
        if ($userId != "") {
            $this->_db->my_query("SET NAMES 'UTF8'");
            //$sql_get_user = "SELECT * FROM users where `id`='" . $userId . "'";
			$sql_get_user = "SELECT u.id,u.fname,u.email,u.status,u.family_name,u.company_name,u.website,u.is_profile,u.phone_number,asl.id as social_id,asl.social_link,asl.username,asl.write_bio,asl.profile_image
				FROM users u
				LEFT JOIN add_social_links asl ON u.id=asl.user_id
				WHERE u.id=$userId"; 
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 if(!empty($row->country_id)){
				 //$records_array['country_name'] = $this->getCountryNameById($row->country_id);
				 }else{
				 //$records_array['country_name']="";
				 }
				if(!empty($row->state_id)){
				//$records_array['state_name'] = $this->getStateNameById($row->state_id);
				}else{
				//$records_array['state_name']="";
				}
				if(!empty($row->city_id)){
				//$records_array['city_name'] = $this->getCityNameById($row->city_id);
				}else{
				//$records_array['city_name']="";
				}
				$records_array['userId'] = $row->id;
				$records_array['name'] = (!empty($row->fname))?$row->fname:'';
                $records_array['email'] = (!empty($row->email))?$row->email:'';
				$records_array['phone_number'] = (!empty($row->phone_number))?$row->phone_number:'';
				$records_array['company_name'] = (!empty($row->company_name))?$row->company_name:'';
				$records_array['family_name'] = (!empty($row->family_name))?$row->family_name:'';
  
                $records_array['is_profile'] = $row->is_profile; //1- enable, 0- disabled
                $records_array['website'] = (!empty($row->website))?$row->website:'';
				$records_array['social_link_id'] = (!empty($row->social_id))?$row->social_id:'';
				$records_array['write_bio'] = (!empty($row->write_bio))?$row->write_bio:'';
				$records_array['username'] = (!empty($row->username))?$row->username:'';
				$userImage   = $row->profile_image;
				if (strpos($userImage, 'http') !== false) {
				$records_array['profile_image'] = $userImage;
				}else{
					if ($userImage != '') {
						$records_array['profile_image'] = USER_FOLDER_PATH.$userImage;
					}else {
						$imgName = "no_img.png";
						$records_array['profile_image'] = USER_FOLDER_PATH.$imgName;
					}
               }
				$social_link = ($row->social_link)?json_decode($row->social_link):'';
                $records_array['social_link'] = (!empty($row->social_link))?$social_link:'';
				
                //$records_array['address'] =(!empty($row->address))?$row->address:'';
                $records_array['createDate'] = (!empty($row->created_at))?$row->created_at:'';
               // $records_array['last_logged_in'] = (!empty($row->last_logged_in))?$row->last_logged_in:'';
				//$records_array['country'] = (!empty($row->country_id))?$row->country_id:'';
				//$records_array['state'] = (!empty($row->state_id))?$row->state_id:'';
				//$records_array['city'] = (!empty($row->city_id))?$row->city_id:'';
				//$records_array['is_email_verify'] = $row->is_email_verify;
				$records_array['status'] = $row->status;
				//$records_array['is_deleted'] = $row->is_deleted;
              
            } 
        } 
		return $records_array;
    }
	
	public function checksocialIdExist($socialId) 
    {
		$locale  = $this->_common->locale();
        if ($socialId != "") {
		
			$result = $this->_common->getUserDetailsBysocialId($socialId);
			if (!empty($result) && $result->status == 1) {
				$res = 1;
            }else if(!empty($result) && $result->status == 0){
				$res = 2;
			}else{
				$res = 0;
			}
            
        } //$emailid != ""
		return $res;
    }
	
	
	public function getUserIdBysocialId($socialId) 
    {
	
        $locale  = $this->_common->locale();
        if ($socialId != "") {
		
			$sql_get_user = "SELECT id FROM users where `socialId`='" . $socialId . "'";
			$get_user     = $this->_db->my_query($sql_get_user);
			$row = $this->_db->my_fetch_object($get_user);
			
			$id =$row->id;
            
        } //$emailid != ""
        return $id;
    }
	
	
	
	public function getUserIdByEmailId($EmailId) 
    {	
        $locale  = $this->_common->locale();
        if ($EmailId != "") {
			$sql_get_user = "SELECT id FROM users where `email`='".$EmailId."'";
			$get_user     = $this->_db->my_query($sql_get_user);
			if($get_user){
			$row = $this->_db->my_fetch_object($get_user);
			$id =$row->id;
			}else{
			$id = "0";
			}
			
            
        } //$emailid != ""
       return $id;
    }
    
	public function forgetPassword() 
    {
		$email    = (isset($_REQUEST['email'])?$_REQUEST['email']:'');
        $locale  = $this->_common->locale();
		$exist=    $this->getUserIdByEmailId($email);
		if(!empty($email)){
        if ($exist) {
			$userIfo = $this->getUserInfo($exist);
			if($userIfo['status'] == 0 && $userIfo['is_deleted']== 1){
			$records_array['status'] = "0";
			$records_array['msg']    = $this->_common->langText($locale, 'account_status');
		}else{
		$to = $email;
		$activation_code = sha1(time()) . mt_rand();
        $sql_update_user = "UPDATE users SET `varification_code`='" .$activation_code. "' WHERE `id`= '".$exist."'";
		$update   = $this->_db->my_query($sql_update_user);
		$emailData= array();
		
		$emailData['first_name'] = ucfirst($userIfo['name']);
		$emailData['text'] = "To reset your password please click the below link :";
		$emailData['url'] = BASE_URL."user/reset_password/".$activation_code;
		$emailData['urlText'] = "Click Here To Reset";
		$emailData['recieverId'] = $email;
		$emailData['subject'] = 'Rigbuy: Password Reset';
		$emailData['template'] = 'email';
		$emailData['code'] = $activation_code;
		$emailData['id']=5;//template id 5 for forget password
		
		$getEmailData = "SELECT * FROM `email_template` where `id`=5";
		$getEmailData     = $this->_db->my_query_result($getEmailData);
		$search    = array("{#FIRSTNAME#}", "{#LINKTOPATH#}");
		$replace   = array($emailData['first_name'], $emailData['url']);
		$emailBody=  str_replace($search, $replace, $getEmailData[0]['body']);
		
		$header = "MIME-Version: 1.0\r\n";
		$header .= "Content-type: text/html\r\n";
		$retval = mail($email,$emailData['subject'],$emailBody,$header);
			if($retval){
				$records_array['status'] = "1";
				$records_array['msg']    = $this->_common->langText($locale,'txt.login.forgot.password.validation');
			}else{
				$records_array['status'] = "0";
				$records_array['msg']    = $this->_common->langText($locale,'forget.mail.error');
			}
		}
		}else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale, 'txt.common.email.not.registered');
		}
		}else{
			$records_array['status'] = "0";
            $records_array['msg']    = $this->_common->langText($locale,'txt.login.blank.email.address.validation');
		}
        return $records_array;
    }
	/**
    * @This function use for imageupload
    * @Input: 
    * @output: return message and status
    * @access public
    */  
    public function imageUpload($encoded_image=null,$upload_path) {
		//print_r($encoded_image); echo '>>> '; print_r($upload_path);
		$decoded_image = base64_decode($encoded_image);
		$f = finfo_open();
        $mime_type = finfo_buffer($f, $decoded_image, FILEINFO_MIME_TYPE);
		$file_type = explode('/', $mime_type);
        if(!empty($file_type[1])){
            $ext = $file_type[1];
        }else{
            $ext = 'png';
        }
        
        $imgname       = md5(uniqid()) . '.'.$ext;
        $ret =  file_put_contents($upload_path."". $imgname, $decoded_image);
        $actual       = $upload_path ."" .$imgname; // Set the actual image name
        
		return $imgname;
    }
	
	 /**
    * @This function use for add social links
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function addSocialLink() {
		
		$userId 		     = (isset($_REQUEST['user_id'])?trim($_REQUEST['user_id']):'');
		$username 		     = (isset($_REQUEST['username'])?trim($_REQUEST['username']):'');
		$write_bio 		     = (isset($_REQUEST['write_bio'])?trim($_REQUEST['write_bio']):'');
        $social_link      	 = $_REQUEST['social_link']; 
		$social_link_id_post = $_REQUEST['social_link_id'];
		$image_url       = (isset($_REQUEST['profile_image'])?$_REQUEST['profile_image']:'');
		//print_r($_REQUEST); 
		$social_link_encode = (!empty($social_link))? json_encode($social_link):'';
		//print_r($social_link_encode);
		//$social_link_decode = json_decode($social_link_encode);
		//print_r($social_link_decode);
		//die; /home/lt33p5y63nv1/public_html/dks/dot/webservices/models/users.php
		
		//echo file_put_contents('/home/lt33p5y63nv1/public_html/dks/dot/webservices/test.txt',"Hello World. Testing!") or print_r(error_get_last()); die;
		if(!empty($image_url)){
				$folder = USER_UPLOAD_PATH;
				$imgByteArr = $_REQUEST['profile_image'];      
				$image_url= $this->imageUpload($imgByteArr,$folder);
		}
		$locale = $this->_common->locale();
		if (!empty($userId) && !empty($username)) {
			//$email_exsits = $this->user_info_by_email(trim($email));
			//print_r($email_exsits); die;
		/* if (!empty($social_link)) {
			  $records_array['status'] = "0";
              $records_array['locale'] = $locale;
			  $records_array['msg']    = $this->_common->langText($locale, 'txt.registration.same.email.address');
		 
		return $records_array;
	   
	   }	*/
	   

       		if(!empty($social_link_id_post)){
				$sql_get_user = "SELECT * from `add_social_links` where `id`='" . $social_link_id_post . "' and `user_id`='" . $userId . "'";
				$get_user     = $this->_db->my_query($sql_get_user);
				$row = $this->_db->my_fetch_object($get_user);
					
				if ($this->_db->my_num_rows($get_user) > 0) 
			  {
			$sqlUp  = " UPDATE add_social_links SET "; 
            $sqlUp .= " username='".$username."' , ";
            $sqlUp .= " write_bio='".$write_bio."',";
			$sqlUp .= " social_link=".$social_link_encode.",";
			$sqlUp .= " profile_image ='".$image_url ."',";
            $sqlUp .= " created_at='".CURRENT_TIME."' ";
            $sqlUp .= " where user_id = $userId and id = $social_link_id_post";
           //echo $sqlUp; die;   
			$resUp = $this->_db->my_query($sqlUp);
			if($resUp){
				$userinfo = $this->getUserInfo($userId);
				//$userSocialLink = $this->getUserSocialLink($userId);
                //$response['id'] = $userId;
				$response['social_link_id'] = $social_link_id_post;
				$response['records'] = $userinfo;
				//$response['social_link'] = $userSocialLink;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "update social link successful."; //, Please check your emailbox for verification email/link.
			}else{
				$response['status']   = "0";
				$response['locale'] = $locale;
				$response['msg'] = "Error!. Parameter is missing.";
			}
		  }else {
			    $response['status']   = "0";
				$response['locale'] = $locale;
				$response['msg'] = "Error!. No record found.";
		  }
				
		} else if(empty($social_link_id_post)){		
            $sql  = " INSERT INTO add_social_links SET ";
            $sql .= " user_id='".$userId."' , ";  
            $sql .= " username='".$username."' , "; 
            $sql .= " write_bio='".$write_bio."',";
            $sql .= " social_link=".$social_link_encode.",";
			$sql .= " profile_image ='".$image_url ."',";
            $sql .= " created_at='".CURRENT_TIME."',";
            $sql .= " status = 1";
          // echo $sql; die; 
				$this->_db->my_query($sql);
				$social_link_id = $this->_db->my_query_id();
			    /*$emailData['first_name'] = ucfirst($name);
				$emailData['recieverId'] = $email;
				$emailData['subject'] = 'Rigbuy: Registration';
				$emailData['template'] = 'email';
				$emailData['url'] = BASE_URL."user/verify_email/".$activation_code;				
				$emailData['code'] = $activation_code;
				$emailData['id']=8;//template id 8 Rigbuy: Registration
				
				$getEmailData = "SELECT * FROM `email_template` where `id`=8";
				$getEmailData     = $this->_db->my_query_result($getEmailData);
				
				$search    = array("{#FIRSTNAME#}", "{#LINKTOPATH#}");
				$replace   = array($emailData['first_name'], $emailData['url']);
				$emailBody=  str_replace($search, $replace, $getEmailData[0]['body']);
		
				$header = "MIME-Version: 1.0\r\n";
				$header .= "Content-type: text/html\r\n";
				$retval = mail($email,$emailData['subject'],$emailBody,$header); */
				
				
            if ($social_link_id) {
				 /*$this->_db->my_query("SET NAMES 'UTF8'");
				//$sql_get_user = "SELECT users.id,users.username,users.email,users.status,add_social_links.social_link FROM users JOIN add_social_links ON add_social_links.user_id=users.id where `users.id`='" . $userId . "'";
				
				$sql_get_user = "SELECT u.id,u.username,u.email,u.status,asl.social_link
				FROM users u
				LEFT JOIN add_social_links asl ON u.id=asl.user_id
				WHERE u.id=$userId"; 
 

				$error ='error';
				$get_user     = $this->_db->my_query($sql_get_user,$error);
				$row = $this->_db->my_fetch_object($get_user);
				if ($this->_db->my_num_rows($get_user) > 0) 
				{
					$records_array['userId'] = $row->id;
					$records_array['username'] = (!empty($row->username))?$row->username:'';
					$records_array['email'] = (!empty($row->email))?$row->email:'';
					$records_array['social_link'] = (!empty($row->social_link))?$row->social_link:'';
				}*/
				$userinfo = $this->getUserInfo($userId);
				//$userSocialLink = $this->getUserSocialLink($userId);
                //$response['id'] = $userId;
				$response['social_link_id'] = $social_link_id;
				$response['records'] = $userinfo;
				//$response['social_link'] = $userSocialLink;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "add socail link successful."; //, Please check your emailbox for verification email/link.
                
            }
		  }
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
	
	 /**
    * @This function use for contactinfo
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function contactinfo() {
		
		$userId 		     	= trim($_REQUEST['user_id']);
		$name 		     		= trim($_REQUEST['name']);
		$phone_number 		    = trim($_REQUEST['phone_number']);
		$family_name 		    = trim($_REQUEST['family_name']);
        $company_name      	 	= $_REQUEST['company_name'];
		//$email      	 		= $_REQUEST['email']; 		
		$website      	 		= $_REQUEST['website']; 
		
		$locale = $this->_common->locale();
		if (!empty($userId)) {
			//$email_exsits = $this->user_info_by_email(trim($email));
			//print_r($email_exsits); die;
		/* if (!empty($social_link)) {
			  $records_array['status'] = "0";
              $records_array['locale'] = $locale;
			  $records_array['msg']    = $this->_common->langText($locale, 'txt.registration.same.email.address');
		 
		return $records_array;
	 
	   }	*/
       			
            $sql  = " UPDATE users SET ";
            //$sql .= " user_id='".$userId."' , ";  
            $sql .= " fname='".$name."' , ";
			$sql .= " phone_number='".$phone_number."' , ";
            $sql .= " family_name='".$family_name."',";
			$sql .= " company_name='".$company_name."',";
			//$sql .= " email ='".$email."',";
			$sql .= " website='".$website."',";
            $sql .= " created_at='".CURRENT_TIME."' ";
            $sql .= " where id = $userId";
           //echo $sql; die;   
				$res = $this->_db->my_query($sql);
				//$user_id = $this->_db->my_query_id();
			    /*$emailData['first_name'] = ucfirst($name);
				$emailData['recieverId'] = $email;
				$emailData['subject'] = 'Rigbuy: Registration';
				$emailData['template'] = 'email';
				$emailData['url'] = BASE_URL."user/verify_email/".$activation_code;				
				$emailData['code'] = $activation_code;
				$emailData['id']=8;//template id 8 Rigbuy: Registration
				
				$getEmailData = "SELECT * FROM `email_template` where `id`=8";
				$getEmailData     = $this->_db->my_query_result($getEmailData);
				
				$search    = array("{#FIRSTNAME#}", "{#LINKTOPATH#}");
				$replace   = array($emailData['first_name'], $emailData['url']);
				$emailBody=  str_replace($search, $replace, $getEmailData[0]['body']);
		
				$header = "MIME-Version: 1.0\r\n";
				$header .= "Content-type: text/html\r\n";
				$retval = mail($email,$emailData['subject'],$emailBody,$header); */
				
				
            if ($res) {
				 /*$this->_db->my_query("SET NAMES 'UTF8'");
				//$sql_get_user = "SELECT users.id,users.username,users.email,users.status,add_social_links.social_link FROM users JOIN add_social_links ON add_social_links.user_id=users.id where `users.id`='" . $userId . "'";
				
				$sql_get_user = "SELECT u.id,u.username,u.email,u.status,asl.social_link
				FROM users u
				LEFT JOIN add_social_links asl ON u.id=asl.user_id
				WHERE u.id=$userId"; 
 

				$error ='error';
				$get_user     = $this->_db->my_query($sql_get_user,$error);
				$row = $this->_db->my_fetch_object($get_user);
				if ($this->_db->my_num_rows($get_user) > 0) 
				{
					$records_array['userId'] = $row->id;
					$records_array['username'] = (!empty($row->username))?$row->username:'';
					$records_array['email'] = (!empty($row->email))?$row->email:'';
					$records_array['social_link'] = (!empty($row->social_link))?$row->social_link:'';
				}*/
				$userinfo = $this->getUserInfo($userId);
				//$userSocialLink = $this->getUserSocialLink($userId);
                //$response['id'] = $userId;
				$response['user_id'] = $userId;
				$response['records'] = $userinfo;
				//$response['social_link'] = $userSocialLink;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "user contact info save successful."; //, Please check your emailbox for verification email/link.
                
            }
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
	
	function getUserSocialLink($userId="") {
        $loginUserId = (isset($_REQUEST['userId'])?$_REQUEST['userId']:''); // mandatary parameter.
        if ($userId != "") {
            $this->_db->my_query("SET NAMES 'UTF8'");
            //$sql_get_user = "SELECT * FROM add_social_links where `user_id`='" . $userId . "'";
            /* $query = "SELECT * FROM add_social_links where `user_id`='" . $userId . "'";
			$result = $this->_db->my_query_result($query);	
			if(count($result) > 0){				
							
				$dataArr=array();
				foreach ($result as $key=>$res){
					
					$dataArr[$key+1]['social_id']=$res['id'];
					$dataArr[$key+1]['username']= ucfirst($res['username']);
					$dataArr[$key+1]['write_bio']= ucfirst($res['write_bio']);
					$dataArr[$key+1]['social_link']= $res['social_link'];
					$dataArr[$key+1]['created_by']=$res['created_by'];
					}
					
				$records_array['status'] = "1";
                $records_array['data'] = $dataArr;
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'get social link successful.';
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            } */
			
			
			$sql_get_user = "SELECT * FROM add_social_links where `user_id`='" . $userId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 
				$records_array['social__link_id'] = $row->id;
				$records_array['username'] = (!empty($row->username))?$row->username:'';
                $records_array['write_bio'] = (!empty($row->write_bio))?$row->write_bio:'';
				$records_array['social_link'] = (!empty($row->social_link))?$row->social_link:'';
                $records_array['createDate'] = (!empty($row->created_at))?$row->created_at:'';
				$records_array['status'] = $row->status;
				
				
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            } 
			
				
				
				
            
        } 
		return $records_array;
    }
	
	/**
    * @This function use for mycircle
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function mycircle() {
		
		$userId  = trim($_REQUEST['user_id']);
		$locale = $this->_common->locale();
		if (!empty($userId)) {
		
            //$sql_get_user = "SELECT * FROM my_circle where `user_id`='" . $userId . "'";
			/* $sql_get_user = "SELECT u.id,u.fname,u.email,u.status,mycircle.following,mycircle.followers,mycircle.network
				FROM users u
				LEFT JOIN my_circle mycircle ON u.id=mycircle.user_id
				WHERE u.id=$userId";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
			
			
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 
				$records_array['id'] = $row->id;
				$records_array['name'] = (!empty($row->fname))?$row->fname:''; 
                $records_array['email'] = (!empty($row->email))?$row->email:'';
				$records_array['network'] = (!empty($row->network))?$row->network:'';
				$records_array['following'] = (!empty($row->following))?$row->following:'';
				$records_array['followers'] = (!empty($row->followers))?$row->followers:'';
                $records_array['createDate'] = (!empty($row->created_at))?$row->created_at:'';
				$records_array['status'] = $row->status;
				
				
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            } */
			//$query = "SELECT u.id,u.fname,u.email,u.status,u.following,u.followers,mycircle.network,mycircle.created_at,mycircle.user_id,mycircle.id as my_circle_id,mycircle.image,mycircle.name
				//FROM users u
				//LEFT JOIN my_circle mycircle ON u.id=mycircle.user_id
				//WHERE u.id=$userId";
			$sql_get_user = "SELECT * FROM users where `id`='" . $userId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 
				$records_array['following'] = (!empty($row->following))?$row->following:'';
                $records_array['followers'] = (!empty($row->followers))?$row->followers:'';
				
				
            }
			
			$query = "SELECT * FROM my_circle where `user_id`='" . $userId . "'";
			$result = $this->_db->my_query_result($query);
		    
			if(count($result) > 0){				
							
				$dataArr=array();
				foreach ($result as $key=>$res){
					//print_r($res);
					$dataArr[$key+1]['my_circle_id']=$res['id'];
					$dataArr[$key+1]['name']= ucfirst($res['name']);
					
					$userImage   = $res['image'];
					if (strpos($userImage, 'http') !== false) {
					$profile_image = $userImage;
					}else{
						if ($userImage != '') {
							$profile_image = USER_FOLDER_PATH.$userImage;
						}else {
							$imgName = "no_img.png";
							$profile_image = USER_FOLDER_PATH.$imgName;
						}
				   }
				   
					$dataArr[$key+1]['image']= $profile_image;
					$dataArr[$key+1]['network']= ucfirst($res['network']);
					//$dataArr[$key+1]['following']= $res['following'];
					//$dataArr[$key+1]['followers']= $res['followers'];
					$dataArr[$key+1]['created_at']=$res['created_at'];
					}
				
                $records_array['my_circle_list'] = $dataArr;	
				$records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'get social link successful.';
            }else{ 
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            }
			
        } else {
            $records_array['status']   = "0";
			$records_array['locale'] = $locale;
			$records_array['msg'] = "Error!. Parameter is missing.";
        }       
        return $records_array;     
	}
	
	/**
    * @This function use for mycircle
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function notifications() {
		
		$userId  = trim($_REQUEST['user_id']);
		$locale = $this->_common->locale();
		if (!empty($userId)) {
		
            //$sql_get_user = "SELECT * FROM my_circle where `user_id`='" . $userId . "'";
			/* $sql_get_user = "SELECT u.id,u.fname,u.email,u.status,mycircle.following,mycircle.followers,mycircle.network
				FROM users u
				LEFT JOIN my_circle mycircle ON u.id=mycircle.user_id
				WHERE u.id=$userId";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
			
			
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 
				$records_array['id'] = $row->id;
				$records_array['name'] = (!empty($row->fname))?$row->fname:''; 
                $records_array['email'] = (!empty($row->email))?$row->email:'';
				$records_array['network'] = (!empty($row->network))?$row->network:'';
				$records_array['following'] = (!empty($row->following))?$row->following:'';
				$records_array['followers'] = (!empty($row->followers))?$row->followers:'';
                $records_array['createDate'] = (!empty($row->created_at))?$row->created_at:'';
				$records_array['status'] = $row->status;
				
				
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            } */
			//$query = "SELECT u.id,u.fname,u.email,u.status,u.following,u.followers,mycircle.network,mycircle.created_at,mycircle.user_id,mycircle.id as my_circle_id,mycircle.image,mycircle.name
				//FROM users u
				//LEFT JOIN my_circle mycircle ON u.id=mycircle.user_id
				//WHERE u.id=$userId";
			/* $sql_get_user = "SELECT * FROM users where `id`='" . $userId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 
				$records_array['following'] = (!empty($row->following))?$row->following:'';
                $records_array['followers'] = (!empty($row->followers))?$row->followers:'';
				
				
            } */
			
			$query = "SELECT * FROM notifications where `user_id`='" . $userId . "'";
			$result = $this->_db->my_query_result($query); 
		
			if(count($result) > 0){				
							
				$dataArr=array();
				foreach ($result as $key=>$res){
					//print_r($res);
					$dataArr[$key+1]['notification_id']=$res['id'];
					$dataArr[$key+1]['name']= ucfirst($res['name']);
					$dataArr[$key+1]['image']= $res['image'];
					$dataArr[$key+1]['network']= ucfirst($res['network']);
					$dataArr[$key+1]['isFollow']= $res['isFollow']; //0-unfollow, 1- follow.
					$dataArr[$key+1]['description']= $res['description'];
					$dataArr[$key+1]['created_at']=$res['created_at'];
					}
				
                $records_array['notification_list'] = $dataArr;	
				$records_array['status'] = "1";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'get notifications successfully.';
            }else{
                $records_array['status'] = "0";
                $records_array['locale'] = $locale;
                $records_array['msg']    = 'No record found.';
            }
			
        } else {
            $records_array['status']   = "0";
			$records_array['locale'] = $locale;
			$records_array['msg'] = "Error!. Parameter is missing.";
        }       
        return $records_array;     
	}
	
	 /**
    * @This function use for contactinfo
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function is_profile() {
		
		$userId 		= trim($_REQUEST['user_id']);
		$is_profile 	= trim($_REQUEST['is_profile']);
		
		$locale = $this->_common->locale();
		if (!empty($userId) && !empty($is_profile)) {
            $sql  = " UPDATE users SET ";
            //$sql .= " user_id='".$userId."' , ";  
            $sql .= " is_profile='".$is_profile."' ";
            $sql .= " where id = $userId";
           //echo $sql; die;   
			$res = $this->_db->my_query($sql);
				
            if ($res) { 
				$response['user_id'] = $userId;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "user profile status updated successfully."; //, Please check your emailbox for verification email/link.
                
            }else{
			  $response['status']   = "0";
			  $response['locale'] = $locale;
			  $response['msg'] = "no record found.";
			}
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
	
	 /**
    * @This function use for addUser
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function addUser() {
		
		$userId 		     = trim($_REQUEST['user_id']);
		$friend_id 		     = trim($_REQUEST['friend_id']);
		//print_r($_REQUEST); 
		$locale = $this->_common->locale();
		if (!empty($userId)) {
			
			$sql_get_user = "SELECT * FROM users where `id`='" . $friend_id . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
			
			$sql_get_user_sociallink = "SELECT `profile_image` FROM add_social_links where `user_id`='" . $userId . "'";
            $get_user_user_sociallink    = $this->_db->my_query($sql_get_user_sociallink);
            $row_user_sociallink = $this->_db->my_fetch_object($get_user_user_sociallink);
			 if ($this->_db->my_num_rows($get_user) > 0) 
            {
				$profile_image   = (!empty($row_user_sociallink->profile_image))?$row_user_sociallink->profile_image:'';
			}
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				 $name    = (!empty($row->fname))?$row->fname:'';
                 $user_id = (!empty($row->id))?$row->id:'';
				 $network = 'twitter'; // following by which socail network.
				 //$image = 'http://4percentmedical.com/dks/dot/webservices/images/images.jpg';
				// $image   = (!empty($row->profile_image))?$row->profile_image:'';
			
            $sql  = " INSERT INTO my_circle SET ";
            $sql .= " user_id='".$userId."' , "; 
			$sql .= " friend_id='".$friend_id."' , "; 			
            $sql .= " name='".$name."' , "; 
            $sql .= " network='".$network."',";
			$sql .= " image='".$profile_image."',";
            $sql .= " created_at='".CURRENT_TIME."'";
            //$sql .= " status = 1";
          // echo $sql; die; 
				$this->_db->my_query($sql);
				$my_circle_id = $this->_db->my_query_id();
			    
            if ($my_circle_id) {
				
				$userinfo = $this->getUserInfo($userId);
				$response['my_circle_id'] = $my_circle_id;
				//$response['records'] = $userinfo;
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "add user successfully."; //, Please check your emailbox for verification email/link.
                
            }
		  }else{
			$response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. There is no record for this user.";  
		  }
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
	
	 /**
    * @This function use for deleteUserMycircle
    * @Input: 
    * @output: return message and status
    * @access public
    */
    public function deleteUserMycircle() {
		
		$userId 		     = trim($_REQUEST['user_id']);
		$my_circle_id 		     = trim($_REQUEST['my_circle_id']);
		//print_r($_REQUEST); 
		$locale = $this->_common->locale();
		if (!empty($userId) && !empty($my_circle_id)) {
			//DELETE FROM `my_circle` WHERE `my_circle`.`id` = 6
			
			$sql_get_user = "SELECT * from `my_circle` where `id`='" . $my_circle_id . "' and `user_id`='" . $userId . "'";
            $get_user     = $this->_db->my_query($sql_get_user);
            $row = $this->_db->my_fetch_object($get_user);
			
            if ($this->_db->my_num_rows($get_user) > 0) 
            {
				
				$sql_get_user = "DELETE FROM `my_circle` where `id`='" . $my_circle_id . "' and `user_id`='" . $userId . "'";
			
				$del = $this->_db->my_query($sql_get_user);
				
			if($del){
                $response['status']   = "1";
				$response['locale'] = $locale;
				$response['msg'] = "user record delete successfully."; //, Please check your emailbox for verification email/link.
			}
                
            
		  }else{
			$response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. There is no record for this user.";  
		  }
        } else {
            $response['status']   = "0";
			$response['locale'] = $locale;
			$response['msg'] = "Error!. Parameter is missing.";
        }       
        return $response;     
	}
    

}
?>
