<?php ini_set("zlib.output_compression", "On");
	/// -- Get Output in Buffer --
	ob_start();

	/// -- Define base path to check it is a correct way to access --
	define('BASEPATH',dirname(__FILE__));
	/// -- Define Lib path --
	define('LIBPATH',"core");
	/// -- Define Directory seprator --
	define('DS',"/");
	/// -- Define Base file extension type --
	define('EXT',".php");
	/// -- Define Encoding --
	define('ENCODING',"UTF-8");

	/// -- Define URL path to pass in the push notification messages. --
	$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
	$base_url .= "://". @$_SERVER['HTTP_HOST'];
	$base_url .= "/rigbuy/";
	define('URL_PATH',$base_url);
	
	$folder_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
	$folder_url .= "://". @$_SERVER['HTTP_HOST'];
	$folder_url .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);
	define('FOLDER_URL_PATH',$folder_url);
	
	define('IMG_URL',URL_PATH."uploads/user/");
	define('THUMB_IMG_URL',URL_PATH."uploads/thumb_img/");
	
?>
