<?php 

/**
	 * Author : RAHUL
	 * Email  : choyalrahul@gmail.com
	 * Timestamp : 31 dec 2017
	 * Copyright : RAHUL
	 *
	 */
	error_reporting(E_ALL);
	 	/// -- Define Image base path --
	define('IMAGE_BASE_PATH','');
	/// -- Define Image root path --
	define('IMAGE_ROOT','');
	define('BASE_URL','http://rigbuy.com/');
	define('IMG_FOLDER_PATH','http://rigbuy.com/uploads/');
	define('category_FOLDER_PATH','http://rigbuy.com/uploads/category/');
	define('service_FOLDER_PATH','http://rigbuy.com/uploads/services/');
	define('product_FOLDER_PATH','http://rigbuy.com/uploads/product/');
	//define('USER_FOLDER_PATH','http://rigbuy.com/uploads/user/');
	define('USER_FOLDER_PATH','http://4percentmedical.com/dks/dot/webservices/images/');
	//define('USER_UPLOAD_PATH','/home/diosmali/Dilip/rigbuy/rigbuy.com/uploads/user/');
	define('USER_UPLOAD_PATH','/home/lt33p5y63nv1/public_html/dks/dot/webservices/images/');
	define('PRODUCT_UPLOAD_PATH','/home/diosmali/Dilip/rigbuy/rigbuy.com/uploads/product/');
	date_default_timezone_set("Asia/Kolkata");
	define('CURRENT_TIME',date('Y-m-d H:i:s'));
	// include enviroment file
	
	
	define('ENVIRONMENT',dirname(__FILE__)."/"."environment.php");

	if(file_exists(ENVIRONMENT)){
		include(ENVIRONMENT);
		
		 /// -- All to catch exception handling --
		try{
		
			/// -- check FIle exists or now --
			if(file_exists(BASEPATH.DS.LIBPATH.DS."common.php")){ 
				/// -- Include File exists or now --
				include(BASEPATH.DS.LIBPATH.DS."common.php");
				/// -- Log Debug Message --
				log_message("debug","common file included");
				/// -- Create Service Object --
				$resService=loadObject("restService");
				/// -- Init Service Object --
				$resService->init();
				/// -- See if need to set Encoding
				if(ENCODING != 'UTF-8')
				$resService->setEncoding(ENCODING);
				/// -- Set output format --
				$format="JSON";	
				$result = $resService->processRequest($format);				
				if($result==""){
					$result=$resService->execute($format);
					$result=$resService->processResponse($result,$format);
				} 
				ob_clean();
				echo $result;	
			}else{
				die("OOPS something goes wrong");
			}	
		}catch(Exception $e){
			die("OOPS something goes wrong");
		}	
		
	}else{
		die("OOPS something goes wrong");
	}	
  
?>