<?php
//echo 'prakash pawar';
// Show all information, defaults to INFO_ALL
phpinfo(); 

?>